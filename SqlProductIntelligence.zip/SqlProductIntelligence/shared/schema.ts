import { pgTable, text, serial, integer, boolean, timestamp, pgEnum, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model from the template - keeping for references
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Define log type enum for database
export const logTypeEnum = pgEnum('log_type', ['info', 'success', 'warning', 'error']);

// Database schema for logs
export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  message: text("message").notNull(),
  type: logTypeEnum("type").notNull(),
});

export const insertLogSchema = createInsertSchema(logs).pick({
  message: true,
  type: true,
});

export type InsertLog = z.infer<typeof insertLogSchema>;
export type LogEntry = typeof logs.$inferSelect;

// For backward compatibility
export interface InsertLogEntry {
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

// Database schema for settings
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  interval: integer("interval").notNull().default(15),
  autoRetry: boolean("auto_retry").notNull().default(true),
  notifications: boolean("notifications").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSettingsSchema = createInsertSchema(settings).pick({
  interval: true,
  autoRetry: true,
  notifications: true,
});

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;

// Database schema for statistics
export const statistics = pgTable("statistics", {
  id: serial("id").primaryKey(),
  boxesOpened: integer("boxes_opened").notNull().default(0),
  successRate: text("success_rate").notNull().default('0%'),
  runningTime: text("running_time").notNull().default('00:00:00'),
  nextCheck: text("next_check").notNull().default('--:--'),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertStatisticsSchema = createInsertSchema(statistics).pick({
  boxesOpened: true,
  successRate: true,
  runningTime: true,
  nextCheck: true,
});

export type InsertStatistics = z.infer<typeof insertStatisticsSchema>;
export type Statistics = typeof statistics.$inferSelect;

// Database schema for automation status
export const automationStatus = pgTable("automation_status", {
  id: serial("id").primaryKey(),
  isRunning: boolean("is_running").notNull().default(false),
  currentAction: text("current_action").notNull().default('Waiting to start'),
  detectionStatus: jsonb("detection_status").notNull().$type<{
    tikTokInterface: boolean;
    browserAccess: boolean;
    treasureBox: boolean | null;
    clickEvents: boolean;
  }>(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAutomationStatusSchema = createInsertSchema(automationStatus).pick({
  isRunning: true,
  currentAction: true,
  detectionStatus: true,
});

export type InsertAutomationStatus = z.infer<typeof insertAutomationStatusSchema>;
export type AutomationStatus = typeof automationStatus.$inferSelect;

// Define WebSocket message types
export enum MessageType {
  LOG = 'log',
  STATUS_UPDATE = 'statusUpdate',
  SETTINGS_UPDATE = 'settingsUpdate',
  STATISTICS_UPDATE = 'statisticsUpdate',
  COMMAND = 'command'
}

// Base WebSocket message interface
export interface WebSocketMessage {
  type: MessageType;
  payload: any;
}

// Specific WebSocket message interfaces
export interface LogMessage extends WebSocketMessage {
  type: MessageType.LOG;
  payload: LogEntry;
}

export interface StatusUpdateMessage extends WebSocketMessage {
  type: MessageType.STATUS_UPDATE;
  payload: AutomationStatus;
}

export interface SettingsUpdateMessage extends WebSocketMessage {
  type: MessageType.SETTINGS_UPDATE;
  payload: Settings;
}

export interface StatisticsUpdateMessage extends WebSocketMessage {
  type: MessageType.STATISTICS_UPDATE;
  payload: Statistics;
}

export interface CommandMessage extends WebSocketMessage {
  type: MessageType.COMMAND;
  payload: {
    command: 'start' | 'stop' | 'updateSettings';
    settings?: Partial<Settings>;
  };
}
