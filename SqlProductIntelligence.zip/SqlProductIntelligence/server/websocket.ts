import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { CommandMessage, MessageType, WebSocketMessage } from '@shared/schema';
import { tikTokAutomation } from './automation';
import { storage } from './storage';

let wss: WebSocketServer;
const clients = new Set<WebSocket>();

// Initialize WebSocket server
export function initializeWebSocketServer(server: Server): void {
  // Configure WebSocket server with explicit path '/ws'
  wss = new WebSocketServer({ 
    server,
    path: '/ws',
    perMessageDeflate: false // Disable compression for Replit environment
  });
  
  console.log('WebSocket server initialized at path: /ws');
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected to WebSocket');
    clients.add(ws);
    
    // Send initial state to the client
    sendInitialState(ws);
    
    // Handle incoming messages
    ws.on('message', async (message: string) => {
      try {
        const parsedMessage = JSON.parse(message) as WebSocketMessage;
        console.log('Received WebSocket message:', parsedMessage.type);
        
        switch (parsedMessage.type) {
          case MessageType.COMMAND:
            await handleCommand(parsedMessage as CommandMessage);
            break;
          default:
            console.warn('Unknown message type:', parsedMessage.type);
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      clients.delete(ws);
    });
    
    // Handle errors
    ws.on('error', (error) => {
      console.error('WebSocket connection error:', error);
      clients.delete(ws);
    });
  });
  
  // Handle server errors
  wss.on('error', (error) => {
    console.error('WebSocket server error:', error);
  });
}

// Send initial state to a client
async function sendInitialState(ws: WebSocket): Promise<void> {
  try {
    // Get current status
    const status = await tikTokAutomation.getStatus();
    
    // Get logs
    const logs = await storage.getLogs();
    
    // Send automation status
    sendToClient(ws, {
      type: MessageType.STATUS_UPDATE,
      payload: status.automationStatus
    });
    
    // Send statistics
    sendToClient(ws, {
      type: MessageType.STATISTICS_UPDATE,
      payload: status.statistics
    });
    
    // Send settings
    sendToClient(ws, {
      type: MessageType.SETTINGS_UPDATE,
      payload: status.settings
    });
    
    // Send logs
    for (const log of logs) {
      sendToClient(ws, {
        type: MessageType.LOG,
        payload: log
      });
    }
  } catch (error) {
    console.error('Error sending initial state:', error);
  }
}

// Handle command messages
async function handleCommand(message: CommandMessage): Promise<void> {
  const { command, settings } = message.payload;
  
  switch (command) {
    case 'start':
      await tikTokAutomation.start();
      break;
    case 'stop':
      await tikTokAutomation.stop();
      break;
    case 'updateSettings':
      if (settings) {
        await tikTokAutomation.updateSettings(settings);
      }
      break;
    default:
      console.warn('Unknown command:', command);
  }
}

// Send message to a specific client
export function sendToClient(client: WebSocket, message: WebSocketMessage): void {
  if (client.readyState === WebSocket.OPEN) {
    client.send(JSON.stringify(message));
  }
}

// Broadcast message to all connected clients
export function broadcastToClients(message: WebSocketMessage): void {
  clients.forEach(client => {
    sendToClient(client, message);
  });
}
