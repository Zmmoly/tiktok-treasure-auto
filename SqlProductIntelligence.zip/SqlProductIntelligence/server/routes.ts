import type { Express, Request, Response } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { tikTokAutomation } from "./automation";
import { initializeWebSocketServer } from "./websocket";
import path from "path";
import fs from "fs";
import { fileURLToPath } from 'url';

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Initialize WebSocket server
  initializeWebSocketServer(httpServer);
  
  // Get the current file URL and convert to directory path (for ES modules)
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);
  
  // Serve APK file for download
  const apkPath = path.join(__dirname, '../android-app/build/output');
  app.use('/downloads', (req: Request, res: Response, next) => {
    // Add header for binary files
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    next();
  }, express.static(apkPath));
  
  // Create a download page
  app.get('/download', (req: Request, res: Response) => {
    res.send(`
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>تنزيل تطبيق TikTok Treasure Auto</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            text-align: center;
            direction: rtl;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
          }
          h1 {
            color: #FF5E8A;
            margin-bottom: 20px;
          }
          .download-btn {
            display: inline-block;
            background: linear-gradient(135deg, #FF5E8A 0%, #D93F6C 100%);
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            margin-top: 20px;
            box-shadow: 0 4px 15px rgba(255, 94, 138, 0.3);
            transition: all 0.3s ease;
          }
          .download-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255, 94, 138, 0.4);
          }
          .instructions {
            text-align: right;
            margin-top: 30px;
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 10px;
          }
          .instructions li {
            margin-bottom: 10px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>تطبيق TikTok Treasure Auto</h1>
          <p>تطبيق متقدم لأتمتة فتح صناديق الكنز في بث TikTok المباشر</p>
          
          <a href="/downloads/tiktok-treasure-auto.apk" class="download-btn">تنزيل التطبيق (APK)</a>
          
          <div class="instructions">
            <h2>تعليمات التثبيت:</h2>
            <ol>
              <li>انقر على زر التنزيل أعلاه لتحميل ملف APK</li>
              <li>افتح ملف APK بعد التنزيل</li>
              <li>قد تحتاج إلى تفعيل خيار "تثبيت من مصادر غير معروفة" في إعدادات الهاتف</li>
              <li>بعد التثبيت، افتح التطبيق وامنح الأذونات المطلوبة</li>
              <li>ابدأ في استخدام التطبيق لفتح صناديق الكنز تلقائيًا</li>
            </ol>
          </div>
        </div>
      </body>
      </html>
    `);
  });
  
  // API Routes
  
  // Get logs
  app.get('/api/logs', async (req, res) => {
    try {
      const logs = await storage.getLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch logs' });
    }
  });
  
  // Clear logs
  app.post('/api/logs/clear', async (req, res) => {
    try {
      await storage.clearLogs();
      res.json({ success: true, message: 'Logs cleared successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to clear logs' });
    }
  });
  
  // Get settings
  app.get('/api/settings', async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });
  
  // Update settings
  app.post('/api/settings', async (req, res) => {
    try {
      const settings = req.body;
      const updatedSettings = await storage.updateSettings(settings);
      await tikTokAutomation.updateSettings(settings);
      res.json(updatedSettings);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update settings' });
    }
  });
  
  // Get automation status and statistics
  app.get('/api/status', async (req, res) => {
    try {
      const status = await tikTokAutomation.getStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch status' });
    }
  });
  
  // Start automation
  app.post('/api/automation/start', async (req, res) => {
    try {
      await tikTokAutomation.start();
      res.json({ success: true, message: 'Automation started' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to start automation' });
    }
  });
  
  // Stop automation
  app.post('/api/automation/stop', async (req, res) => {
    try {
      await tikTokAutomation.stop();
      res.json({ success: true, message: 'Automation stopped' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to stop automation' });
    }
  });

  return httpServer;
}
