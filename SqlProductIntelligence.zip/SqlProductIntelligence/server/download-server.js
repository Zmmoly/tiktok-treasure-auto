import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const app = express();
const PORT = process.env.PORT || 3000;

// Get the current file URL and convert to directory path
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve static files from the 'android-app/build/output' directory
app.use('/downloads', express.static(path.join(__dirname, '../android-app/build/output')));

// Create a simple download page
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>تنزيل تطبيق TikTok Treasure Auto</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          margin: 0;
          padding: 20px;
          background-color: #f5f5f5;
          text-align: center;
          direction: rtl;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          background: white;
          padding: 20px;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
          color: #FF5E8A;
          margin-bottom: 20px;
        }
        .download-btn {
          display: inline-block;
          background: linear-gradient(135deg, #FF5E8A 0%, #D93F6C 100%);
          color: white;
          padding: 15px 30px;
          text-decoration: none;
          border-radius: 50px;
          font-weight: bold;
          margin-top: 20px;
          box-shadow: 0 4px 15px rgba(255, 94, 138, 0.3);
          transition: all 0.3s ease;
        }
        .download-btn:hover {
          transform: translateY(-3px);
          box-shadow: 0 6px 20px rgba(255, 94, 138, 0.4);
        }
        .instructions {
          text-align: right;
          margin-top: 30px;
          background-color: #f9f9f9;
          padding: 15px;
          border-radius: 10px;
        }
        .instructions li {
          margin-bottom: 10px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>تطبيق TikTok Treasure Auto</h1>
        <p>تطبيق متقدم لأتمتة فتح صناديق الكنز في بث TikTok المباشر</p>
        
        <a href="/downloads/tiktok-treasure-auto.apk" class="download-btn">تنزيل التطبيق (APK)</a>
        
        <div class="instructions">
          <h2>تعليمات التثبيت:</h2>
          <ol>
            <li>انقر على زر التنزيل أعلاه لتحميل ملف APK</li>
            <li>افتح ملف APK بعد التنزيل</li>
            <li>قد تحتاج إلى تفعيل خيار "تثبيت من مصادر غير معروفة" في إعدادات الهاتف</li>
            <li>بعد التثبيت، افتح التطبيق وامنح الأذونات المطلوبة</li>
            <li>ابدأ في استخدام التطبيق لفتح صناديق الكنز تلقائيًا</li>
          </ol>
        </div>
      </div>
    </body>
    </html>
  `);
});

// Check if APK file exists
const apkPath = path.join(__dirname, '../android-app/build/output/tiktok-treasure-auto.apk');
if (!fs.existsSync(apkPath)) {
  console.error('Error: APK file not found at ' + apkPath);
  process.exit(1);
}

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Download server running at http://0.0.0.0:${PORT}`);
  console.log(`Direct APK download link: http://0.0.0.0:${PORT}/downloads/tiktok-treasure-auto.apk`);
});