import { 
  type User, 
  type InsertUser, 
  type LogEntry, 
  type InsertLogEntry, 
  type Settings, 
  type Statistics, 
  type AutomationStatus,
  type InsertLog,
  type InsertSettings,
  type InsertStatistics,
  type InsertAutomationStatus
} from "@shared/schema";
import { 
  users, 
  logs, 
  settings, 
  statistics, 
  automationStatus 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

// Enhanced storage interface with our automation-specific models
export interface IStorage {
  // User operations (from template)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Automation log operations
  getLogs(): Promise<LogEntry[]>;
  addLog(log: InsertLogEntry): Promise<LogEntry>;
  clearLogs(): Promise<void>;
  
  // Settings operations
  getSettings(): Promise<Settings>;
  updateSettings(settings: Partial<Settings>): Promise<Settings>;
  
  // Statistics operations
  getStatistics(): Promise<Statistics>;
  updateStatistics(statistics: Partial<Statistics>): Promise<Statistics>;
  incrementBoxesOpened(): Promise<number>;
  
  // Automation status operations
  getAutomationStatus(): Promise<AutomationStatus>;
  updateAutomationStatus(status: Partial<AutomationStatus>): Promise<AutomationStatus>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize the database with default records if they don't exist
    this.initializeDatabase();
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Initialize settings if not exists
      const settingsData = await db.select().from(settings).limit(1);
      if (settingsData.length === 0) {
        await db.insert(settings).values({
          interval: 15,
          autoRetry: true,
          notifications: true
        });
      }

      // Initialize statistics if not exists
      const statsData = await db.select().from(statistics).limit(1);
      if (statsData.length === 0) {
        await db.insert(statistics).values({
          boxesOpened: 0,
          successRate: '0%',
          runningTime: '00:00:00',
          nextCheck: '--:--'
        });
      }

      // Initialize automation status if not exists
      const statusData = await db.select().from(automationStatus).limit(1);
      if (statusData.length === 0) {
        await db.insert(automationStatus).values({
          isRunning: false,
          currentAction: 'Waiting to start',
          detectionStatus: {
            tikTokInterface: false,
            browserAccess: false,
            treasureBox: null,
            clickEvents: false
          }
        });
      }
    } catch (error) {
      console.error('Error initializing database:', error);
    }
  }

  // User methods (from template)
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Log methods
  async getLogs(): Promise<LogEntry[]> {
    return await db.select().from(logs).orderBy(desc(logs.timestamp)).limit(100);
  }
  
  async addLog(insertLog: InsertLogEntry): Promise<LogEntry> {
    const logData: InsertLog = {
      message: insertLog.message,
      type: insertLog.type
    };
    
    const [log] = await db.insert(logs).values(logData).returning();
    
    return log;
  }
  
  async clearLogs(): Promise<void> {
    await db.delete(logs);
  }
  
  // Settings methods
  async getSettings(): Promise<Settings> {
    const [setting] = await db.select().from(settings).limit(1);
    
    if (!setting) {
      // If no settings exist, create default and return
      const [newSetting] = await db.insert(settings).values({
        interval: 15,
        autoRetry: true,
        notifications: true
      }).returning();
      
      return newSetting;
    }
    
    return setting;
  }
  
  async updateSettings(partialSettings: Partial<Settings>): Promise<Settings> {
    // Get the first settings record's ID
    const [currentSetting] = await db.select().from(settings).limit(1);
    
    if (!currentSetting) {
      // If no settings exist, create with the provided values
      const defaultSettings: InsertSettings = {
        interval: partialSettings.interval ?? 15,
        autoRetry: partialSettings.autoRetry ?? true,
        notifications: partialSettings.notifications ?? true
      };
      
      const [newSetting] = await db.insert(settings).values(defaultSettings).returning();
      return newSetting;
    }
    
    // Update the existing settings
    const [updatedSetting] = await db
      .update(settings)
      .set({
        ...partialSettings,
        updatedAt: new Date()
      })
      .where(eq(settings.id, currentSetting.id))
      .returning();
    
    return updatedSetting;
  }
  
  // Statistics methods
  async getStatistics(): Promise<Statistics> {
    const [stat] = await db.select().from(statistics).limit(1);
    
    if (!stat) {
      // If no statistics exist, create default and return
      const [newStat] = await db.insert(statistics).values({
        boxesOpened: 0,
        successRate: '0%',
        runningTime: '00:00:00',
        nextCheck: '--:--'
      }).returning();
      
      return newStat;
    }
    
    return stat;
  }
  
  async updateStatistics(partialStatistics: Partial<Statistics>): Promise<Statistics> {
    // Get the first statistics record's ID
    const [currentStat] = await db.select().from(statistics).limit(1);
    
    if (!currentStat) {
      // If no statistics exist, create with the provided values
      const defaultStats: InsertStatistics = {
        boxesOpened: partialStatistics.boxesOpened ?? 0,
        successRate: partialStatistics.successRate ?? '0%',
        runningTime: partialStatistics.runningTime ?? '00:00:00',
        nextCheck: partialStatistics.nextCheck ?? '--:--'
      };
      
      const [newStat] = await db.insert(statistics).values(defaultStats).returning();
      return newStat;
    }
    
    // Update the existing statistics
    const [updatedStat] = await db
      .update(statistics)
      .set({
        ...partialStatistics,
        updatedAt: new Date()
      })
      .where(eq(statistics.id, currentStat.id))
      .returning();
    
    return updatedStat;
  }
  
  async incrementBoxesOpened(): Promise<number> {
    // Get current statistics
    const [currentStat] = await db.select().from(statistics).limit(1);
    
    if (!currentStat) {
      // If no statistics exist, create with boxesOpened = 1
      const [newStat] = await db.insert(statistics).values({
        boxesOpened: 1,
        successRate: '100%',
        runningTime: '00:00:00',
        nextCheck: '--:--'
      }).returning();
      
      return newStat.boxesOpened;
    }
    
    // Increment boxesOpened and update success rate
    const newBoxesOpened = currentStat.boxesOpened + 1;
    const totalAttempts = newBoxesOpened; // We could track failed attempts separately
    const successRatePercent = Math.round((newBoxesOpened / Math.max(1, totalAttempts)) * 100);
    
    // Update the existing statistics
    const [updatedStat] = await db
      .update(statistics)
      .set({
        boxesOpened: newBoxesOpened,
        successRate: `${successRatePercent}%`,
        updatedAt: new Date()
      })
      .where(eq(statistics.id, currentStat.id))
      .returning();
    
    return updatedStat.boxesOpened;
  }
  
  // Automation status methods
  async getAutomationStatus(): Promise<AutomationStatus> {
    const [status] = await db.select().from(automationStatus).limit(1);
    
    if (!status) {
      // If no status exists, create default and return
      const [newStatus] = await db.insert(automationStatus).values({
        isRunning: false,
        currentAction: 'Waiting to start',
        detectionStatus: {
          tikTokInterface: false,
          browserAccess: false,
          treasureBox: null,
          clickEvents: false
        }
      }).returning();
      
      return newStatus;
    }
    
    return status;
  }
  
  async updateAutomationStatus(partialStatus: Partial<AutomationStatus>): Promise<AutomationStatus> {
    // Get the first automation status record's ID
    const [currentStatus] = await db.select().from(automationStatus).limit(1);
    
    if (!currentStatus) {
      // Prepare default status with any provided values
      const detectionStatus = partialStatus.detectionStatus ?? {
        tikTokInterface: false,
        browserAccess: false,
        treasureBox: null,
        clickEvents: false
      };
      
      const defaultStatus: InsertAutomationStatus = {
        isRunning: partialStatus.isRunning ?? false,
        currentAction: partialStatus.currentAction ?? 'Waiting to start',
        detectionStatus
      };
      
      const [newStatus] = await db.insert(automationStatus).values(defaultStatus).returning();
      return newStatus;
    }
    
    // If detectionStatus is included, merge it with the existing one
    let updatedDetectionStatus = currentStatus.detectionStatus;
    if (partialStatus.detectionStatus) {
      updatedDetectionStatus = {
        ...currentStatus.detectionStatus,
        ...partialStatus.detectionStatus
      };
    }
    
    // Create the update object
    const updateData: any = { ...partialStatus, updatedAt: new Date() };
    
    // Replace detectionStatus with the merged version
    if (partialStatus.detectionStatus) {
      updateData.detectionStatus = updatedDetectionStatus;
    }
    
    // Update the existing automation status
    const [updatedStatus] = await db
      .update(automationStatus)
      .set(updateData)
      .where(eq(automationStatus.id, currentStatus.id))
      .returning();
    
    return updatedStatus;
  }
}

export const storage = new DatabaseStorage();
