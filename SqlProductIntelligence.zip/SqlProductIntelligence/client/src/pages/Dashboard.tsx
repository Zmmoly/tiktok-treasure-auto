import { useEffect } from "react";
import ControlPanel from "@/components/controlPanel/ControlPanel";
import StatusMonitor from "@/components/statusMonitor/StatusMonitor";
import SetupGuide from "@/components/setupGuide/SetupGuide";
import { useAutomation } from "@/hooks/useAutomation";

export default function Dashboard() {
  const { 
    isRunning, 
    logs, 
    settings, 
    statistics, 
    currentAction,
    detectionStatus,
    startAutomation, 
    stopAutomation, 
    updateSettings, 
    clearLogs 
  } = useAutomation();

  // Set page title
  useEffect(() => {
    document.title = "TikTok Treasure Box Automation";
  }, []);

  return (
    <div className="min-h-screen bg-neutral-100">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <header className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-2xl font-medium text-neutral-400 flex items-center">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-6 h-6 mr-2 text-secondary"
              >
                <path d="M21 8a2 2 0 0 0-2-2h-8.5a2 2 0 0 1-2-2V3a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v4h18V8Z" />
                <path d="M10.55 21H4a2 2 0 0 1-2-2V8h18v10a2 2 0 0 1-2 2h-2.04" />
                <path d="M14 18v-1.52a2.5 2.5 0 0 0-5 0V18" />
                <path d="M7 11h2" />
                <path d="M7 15h2" />
              </svg>
              TikTok Treasure Box Automation
            </h1>
            <div className="bg-neutral-200 rounded-full px-3 py-1 text-sm flex items-center">
              <span 
                className={`h-3 w-3 rounded-full mr-2 ${isRunning 
                  ? 'bg-success animate-pulse' 
                  : 'bg-warning'}`}
              ></span>
              <span>{isRunning ? 'Running' : 'Ready'}</span>
            </div>
          </div>
          <p className="text-neutral-300 text-sm">
            Automatically collect TikTok Treasure boxes with minimal effort.
          </p>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ControlPanel
            isRunning={isRunning}
            settings={settings}
            statistics={statistics}
            startAutomation={startAutomation}
            stopAutomation={stopAutomation}
            updateSettings={updateSettings}
          />
          
          <StatusMonitor
            logs={logs}
            currentAction={currentAction}
            detectionStatus={detectionStatus}
            clearLogs={clearLogs}
          />
        </main>

        <SetupGuide />
        
        <footer className="mt-8 text-center text-sm text-neutral-300">
          <p>TikTok Treasure Box Automation Tool &copy; {new Date().getFullYear()}</p>
          <p className="text-xs mt-1">This tool is not affiliated with TikTok</p>
        </footer>
      </div>
    </div>
  );
}
