import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { X } from "lucide-react";

import { cn } from "@/lib/utils";

const notificationVariants = cva(
  "fixed top-4 right-4 w-80 bg-white shadow-lg rounded-md p-4 transform transition-transform duration-300 z-50",
  {
    variants: {
      variant: {
        default: "border-l-4 border-primary",
        success: "border-l-4 border-success",
        error: "border-l-4 border-destructive",
        warning: "border-l-4 border-warning",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface NotificationProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof notificationVariants> {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  onClose?: () => void;
}

const Notification = React.forwardRef<HTMLDivElement, NotificationProps>(
  ({ className, variant, title, description, icon, onClose, ...props }, ref) => {
    return (
      <div
        className={cn(notificationVariants({ variant }), className)}
        ref={ref}
        {...props}
      >
        <div className="flex items-start">
          {icon && <div className="flex-shrink-0">{icon}</div>}
          <div className={cn("w-0 flex-1", icon && "ml-3")}>
            <p className="text-sm font-medium text-neutral-400">{title}</p>
            {description && (
              <p className="mt-1 text-sm text-neutral-300">{description}</p>
            )}
          </div>
          {onClose && (
            <div className="ml-4 flex-shrink-0 flex">
              <button
                className="inline-flex text-neutral-300 hover:text-neutral-400"
                onClick={onClose}
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }
);

Notification.displayName = "Notification";

export { Notification, notificationVariants };
