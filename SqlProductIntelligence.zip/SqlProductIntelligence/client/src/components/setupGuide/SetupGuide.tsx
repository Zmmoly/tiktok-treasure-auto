import { useState } from 'react';
import { cn } from '@/lib/utils';

export default function SetupGuide() {
  const [isExpanded, setIsExpanded] = useState(true);
  
  return (
    <div className="mt-8 bg-white rounded-lg shadow-md p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5 mr-2 text-primary"
          >
            <circle cx="12" cy="12" r="10" />
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
          Quick Setup Guide
        </h2>
        <button 
          className="text-primary hover:text-primary/80 text-sm flex items-center"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={cn("w-5 h-5", isExpanded ? "rotate-180" : "")}
          >
            <polyline points="6 9 12 15 18 9" />
          </svg>
        </button>
      </div>
      
      <div className={cn("text-sm text-neutral-300 space-y-3", !isExpanded && "hidden")}>
        <p>Follow these steps to set up the automation:</p>
        <ol className="list-decimal pl-5 space-y-2">
          <li>Connect your Android device to your computer via USB</li>
          <li>Enable USB debugging in Android Developer Options</li>
          <li>Install the TikTok app and log in to your account</li>
          <li>Click the "Start" button to begin automation</li>
          <li>You can adjust the check interval in the settings</li>
        </ol>
        <div className="bg-warning bg-opacity-10 p-3 rounded-md text-warning flex items-start mt-3">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5 mr-2 flex-shrink-0"
          >
            <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
            <line x1="12" y1="9" x2="12" y2="13" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
          <p>This tool only works with the TikTok Android app, not the web version. You must have an Android device or emulator connected to use this tool.</p>
        </div>
        <div className="bg-primary bg-opacity-10 p-3 rounded-md text-primary flex items-start mt-3">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5 mr-2 flex-shrink-0"
          >
            <circle cx="12" cy="12" r="10" />
            <path d="M12 16v-4" />
            <path d="M12 8h.01" />
          </svg>
          <p>Treasure Boxes are only available in the Android app of TikTok. Our automation tool uses Android Debug Bridge (ADB) to control your device and automatically collect treasure boxes.</p>
        </div>
      </div>
    </div>
  );
}
