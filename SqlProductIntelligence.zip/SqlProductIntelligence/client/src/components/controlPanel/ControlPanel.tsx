import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Settings, Statistics } from '@shared/schema';

interface ControlPanelProps {
  isRunning: boolean;
  settings: Settings;
  statistics: Statistics;
  startAutomation: () => Promise<void>;
  stopAutomation: () => Promise<void>;
  updateSettings: (settings: Partial<Settings>) => Promise<void>;
}

export default function ControlPanel({
  isRunning,
  settings,
  statistics,
  startAutomation,
  stopAutomation,
  updateSettings
}: ControlPanelProps) {
  const [intervalValue, setIntervalValue] = useState<number>(settings.interval);
  
  const handleIntervalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value >= 5 && value <= 60) {
      setIntervalValue(value);
    }
  };
  
  const handleIntervalBlur = () => {
    if (intervalValue !== settings.interval) {
      updateSettings({ interval: intervalValue });
    }
  };
  
  const handleToggleAutoRetry = (checked: boolean) => {
    updateSettings({ autoRetry: checked });
  };
  
  const handleToggleNotifications = (checked: boolean) => {
    updateSettings({ notifications: checked });
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-5 md:col-span-1">
      <h2 className="text-lg font-medium mb-4 flex items-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-primary"
        >
          <rect width="18" height="18" x="3" y="3" rx="2" />
          <path d="M7 7h10" />
          <path d="M7 12h10" />
          <path d="M7 17h10" />
        </svg>
        Control Panel
      </h2>
      
      <div className="space-y-5">
        <div>
          <p className="text-sm text-neutral-300 mb-2">Automation Status</p>
          <div className="flex items-center justify-between bg-neutral-100 p-3 rounded-md">
            <span className="flex items-center">
              {isRunning ? (
                <>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="w-5 h-5 mr-2 text-success"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <path d="M12 16v-4" />
                    <path d="M12 8h.01" />
                  </svg>
                  <span>Active</span>
                </>
              ) : (
                <>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="w-5 h-5 mr-2 text-warning"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <path d="M10 15v-5h4v5" />
                  </svg>
                  <span>Idle</span>
                </>
              )}
            </span>
            <div className="space-x-2">
              <Button
                variant="default"
                size="sm"
                className="bg-success hover:bg-success/90 text-white"
                onClick={startAutomation}
                disabled={isRunning}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-4 h-4 mr-1"
                >
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
                Start
              </Button>
              <Button
                variant="default"
                size="sm"
                className="bg-destructive hover:bg-destructive/90 text-white"
                onClick={stopAutomation}
                disabled={!isRunning}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-4 h-4 mr-1"
                >
                  <rect width="6" height="16" x="9" y="4" />
                  <rect width="6" height="16" x="3" y="4" />
                </svg>
                Stop
              </Button>
            </div>
          </div>
        </div>

        <div>
          <p className="text-sm text-neutral-300 mb-2">Performance</p>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-neutral-100 p-3 rounded-md">
              <p className="text-xs text-neutral-300">Boxes Opened</p>
              <p className="text-xl font-medium text-primary">{statistics.boxesOpened}</p>
            </div>
            <div className="bg-neutral-100 p-3 rounded-md">
              <p className="text-xs text-neutral-300">Success Rate</p>
              <p className="text-xl font-medium text-success">{statistics.successRate}</p>
            </div>
            <div className="bg-neutral-100 p-3 rounded-md">
              <p className="text-xs text-neutral-300">Running Time</p>
              <p className="text-xl font-medium">{statistics.runningTime}</p>
            </div>
            <div className="bg-neutral-100 p-3 rounded-md">
              <p className="text-xs text-neutral-300">Next Check</p>
              <p className="text-xl font-medium text-accent">{statistics.nextCheck}</p>
            </div>
          </div>
        </div>

        <div>
          <p className="text-sm text-neutral-300 mb-2">Settings</p>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Check Interval</span>
              <div className="flex items-center space-x-2">
                <Input
                  type="number"
                  min="5"
                  max="60"
                  value={intervalValue}
                  onChange={handleIntervalChange}
                  onBlur={handleIntervalBlur}
                  className="w-16 p-1 text-right"
                />
                <span className="text-sm text-neutral-300">min</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="auto-retry" className="text-sm">Auto-retry on error</Label>
              <Switch
                id="auto-retry"
                checked={settings.autoRetry}
                onCheckedChange={handleToggleAutoRetry}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="notifications" className="text-sm">Notifications</Label>
              <Switch
                id="notifications"
                checked={settings.notifications}
                onCheckedChange={handleToggleNotifications}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
