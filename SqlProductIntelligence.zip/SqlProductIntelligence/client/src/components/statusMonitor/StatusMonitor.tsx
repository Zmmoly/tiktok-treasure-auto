import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { LogEntry, AutomationStatus } from '@shared/schema';

interface StatusMonitorProps {
  logs: LogEntry[];
  currentAction: string;
  detectionStatus: AutomationStatus['detectionStatus'];
  clearLogs: () => Promise<void>;
}

export default function StatusMonitor({
  logs,
  currentAction,
  detectionStatus,
  clearLogs
}: StatusMonitorProps) {
  // Helper to format timestamp
  const formatTimestamp = (date: Date) => {
    const d = new Date(date);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}:${d.getSeconds().toString().padStart(2, '0')}`;
  };
  
  // Helper to get border color based on log type
  const getLogBorderColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'success': return 'border-success';
      case 'error': return 'border-error';
      case 'warning': return 'border-warning';
      default: return 'border-neutral-300';
    }
  };
  
  // Helper to get icon based on detection status
  const getStatusIcon = (status: boolean | null) => {
    if (status === true) {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-success"
        >
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
          <polyline points="22 4 12 14.01 9 11.01" />
        </svg>
      );
    } else if (status === false) {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-error"
        >
          <circle cx="12" cy="12" r="10" />
          <line x1="15" y1="9" x2="9" y2="15" />
          <line x1="9" y1="9" x2="15" y2="15" />
        </svg>
      );
    } else {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-neutral-300"
        >
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="16" x2="12" y2="12" />
          <line x1="12" y1="8" x2="12.01" y2="8" />
        </svg>
      );
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-5 md:col-span-2">
      <h2 className="text-lg font-medium mb-4 flex items-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-primary"
        >
          <path d="M3 3v18h18" />
          <path d="m19 9-5 5-4-4-3 3" />
        </svg>
        Status Monitor
      </h2>
      
      <ScrollArea className="h-96 bg-neutral-100 rounded-md p-3 font-mono text-sm">
        <div className="space-y-2">
          {logs.length > 0 ? (
            logs.map((log) => (
              <div 
                key={log.id} 
                className={cn(
                  "log-entry p-2 border-l-4 bg-white rounded",
                  getLogBorderColor(log.type)
                )}
              >
                <div className="flex items-start">
                  <span className="text-xs text-neutral-300 mr-2">
                    {formatTimestamp(log.timestamp)}
                  </span>
                  <p className="text-neutral-400">{log.message}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center p-4 text-neutral-300">
              No logs yet. Start the automation to see activity here.
            </div>
          )}
        </div>
      </ScrollArea>
      
      <div className="mt-4 space-y-4">
        <div className="bg-primary bg-opacity-10 p-3 rounded-md flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5 mr-2 text-primary animate-pulse"
          >
            <path d="M21 12a9 9 0 1 1-9-9" />
            <path d="M12 12h.01" />
          </svg>
          <div>
            <p className="text-sm font-medium">Current Action</p>
            <p className="text-sm text-neutral-300">{currentAction}</p>
          </div>
        </div>
        
        <div className="bg-neutral-100 p-3 rounded-md">
          <h3 className="text-sm font-medium mb-2">Detection Status</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center">
              {getStatusIcon(detectionStatus.tikTokInterface)}
              <span className="text-sm">TikTok Interface</span>
            </div>
            <div className="flex items-center">
              {getStatusIcon(detectionStatus.browserAccess)}
              <span className="text-sm">Browser Access</span>
            </div>
            <div className="flex items-center">
              {getStatusIcon(detectionStatus.treasureBox)}
              <span className="text-sm">Treasure Box</span>
            </div>
            <div className="flex items-center">
              {getStatusIcon(detectionStatus.clickEvents)}
              <span className="text-sm">Click Events</span>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Button
            variant="ghost"
            size="sm"
            className="text-primary hover:text-primary/80"
            onClick={clearLogs}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4 mr-1"
            >
              <path d="M3 6h18" />
              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
            </svg>
            Clear Logs
          </Button>
        </div>
      </div>
    </div>
  );
}
