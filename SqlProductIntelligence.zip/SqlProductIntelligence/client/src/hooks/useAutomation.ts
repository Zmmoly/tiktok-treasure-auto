import { useState, useEffect, useCallback } from 'react';
import { useWebSocket } from './useWebSocket';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  Settings, 
  Statistics, 
  LogEntry, 
  AutomationStatus, 
  MessageType,
  WebSocketMessage
} from '@shared/schema';

export function useAutomation() {
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [settings, setSettings] = useState<Settings>({
    interval: 15,
    autoRetry: true,
    notifications: true
  });
  const [statistics, setStatistics] = useState<Statistics>({
    boxesOpened: 0,
    successRate: '0%',
    runningTime: '00:00:00',
    nextCheck: '--:--'
  });
  const [currentAction, setCurrentAction] = useState<string>('Waiting to start');
  const [detectionStatus, setDetectionStatus] = useState<AutomationStatus['detectionStatus']>({
    tikTokInterface: false,
    browserAccess: false,
    treasureBox: null,
    clickEvents: false
  });
  
  // WebSocket connection for real-time updates
  const { connected, sendMessage } = useWebSocket({
    onMessage: handleWebSocketMessage
  });

  // Handle WebSocket messages
  function handleWebSocketMessage(message: WebSocketMessage) {
    switch (message.type) {
      case MessageType.LOG:
        const newLog = message.payload as LogEntry;
        setLogs(prevLogs => [newLog, ...prevLogs]);
        
        // Show notification for important logs if enabled
        if (settings.notifications) {
          if (newLog.type === 'success' && newLog.message.includes('Treasure box opened')) {
            toast({
              title: 'Success!',
              description: 'Treasure box opened successfully.',
              variant: 'default'
            });
          } else if (newLog.type === 'error') {
            toast({
              title: 'Error',
              description: newLog.message,
              variant: 'destructive'
            });
          }
        }
        break;
        
      case MessageType.STATUS_UPDATE:
        const status = message.payload as AutomationStatus;
        setIsRunning(status.isRunning);
        setCurrentAction(status.currentAction);
        setDetectionStatus(status.detectionStatus);
        break;
        
      case MessageType.SETTINGS_UPDATE:
        setSettings(message.payload as Settings);
        break;
        
      case MessageType.STATISTICS_UPDATE:
        setStatistics(message.payload as Statistics);
        break;
    }
  }

  // Initialize - fetch initial data
  useEffect(() => {
    async function fetchInitialData() {
      try {
        const response = await apiRequest('GET', '/api/status');
        const data = await response.json();
        
        setIsRunning(data.automationStatus.isRunning);
        setCurrentAction(data.automationStatus.currentAction);
        setDetectionStatus(data.automationStatus.detectionStatus);
        setStatistics(data.statistics);
        setSettings(data.settings);
        
        const logsResponse = await apiRequest('GET', '/api/logs');
        const logsData = await logsResponse.json();
        setLogs(logsData);
      } catch (error) {
        console.error('Error fetching initial data:', error);
        toast({
          title: 'Connection Error',
          description: 'Failed to connect to server. Please refresh the page.',
          variant: 'destructive'
        });
      }
    }
    
    fetchInitialData();
  }, [toast]);

  // Start automation
  const startAutomation = useCallback(async () => {
    try {
      if (connected) {
        // Use WebSocket for real-time communication
        sendMessage({
          type: MessageType.COMMAND,
          payload: {
            command: 'start'
          }
        });
      } else {
        // Fallback to REST API
        await apiRequest('POST', '/api/automation/start');
        toast({
          title: 'Automation Started',
          description: 'The system is now actively monitoring for treasure boxes.',
        });
      }
    } catch (error) {
      console.error('Error starting automation:', error);
      toast({
        title: 'Failed to Start',
        description: 'Could not start the automation. Please try again.',
        variant: 'destructive'
      });
    }
  }, [connected, sendMessage, toast]);

  // Stop automation
  const stopAutomation = useCallback(async () => {
    try {
      if (connected) {
        // Use WebSocket for real-time communication
        sendMessage({
          type: MessageType.COMMAND,
          payload: {
            command: 'stop'
          }
        });
      } else {
        // Fallback to REST API
        await apiRequest('POST', '/api/automation/stop');
        toast({
          title: 'Automation Stopped',
          description: 'The system has been stopped.',
        });
      }
    } catch (error) {
      console.error('Error stopping automation:', error);
      toast({
        title: 'Failed to Stop',
        description: 'Could not stop the automation. Please try again.',
        variant: 'destructive'
      });
    }
  }, [connected, sendMessage, toast]);

  // Update settings
  const updateSettings = useCallback(async (newSettings: Partial<Settings>) => {
    try {
      // Update local state immediately
      setSettings(prevSettings => ({ ...prevSettings, ...newSettings }));
      
      if (connected) {
        // Use WebSocket for real-time communication
        sendMessage({
          type: MessageType.COMMAND,
          payload: {
            command: 'updateSettings',
            settings: newSettings
          }
        });
      } else {
        // Fallback to REST API
        await apiRequest('POST', '/api/settings', newSettings);
      }
    } catch (error) {
      console.error('Error updating settings:', error);
      toast({
        title: 'Failed to Update Settings',
        description: 'Could not update settings. Please try again.',
        variant: 'destructive'
      });
    }
  }, [connected, sendMessage, toast]);

  // Clear logs
  const clearLogs = useCallback(async () => {
    try {
      await apiRequest('POST', '/api/logs/clear');
      setLogs([]);
      toast({
        title: 'Logs Cleared',
        description: 'All logs have been cleared.',
      });
    } catch (error) {
      console.error('Error clearing logs:', error);
      toast({
        title: 'Failed to Clear Logs',
        description: 'Could not clear logs. Please try again.',
        variant: 'destructive'
      });
    }
  }, [toast]);

  return {
    isRunning,
    logs,
    settings,
    statistics,
    currentAction,
    detectionStatus,
    startAutomation,
    stopAutomation,
    updateSettings,
    clearLogs
  };
}
