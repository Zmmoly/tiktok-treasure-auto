package com.tiktoktreasureauto.models;

/**
 * Model class for heat map data entries
 */
public class HeatMapEntry {
    private int id;
    private int hour;
    private int attempts;
    private int successes;
    private float successRate;
    private String lastUpdated;
    
    // Default constructor
    public HeatMapEntry() {
    }
    
    // Constructor with hour
    public HeatMapEntry(int hour) {
        this.hour = hour;
        this.attempts = 0;
        this.successes = 0;
        this.successRate = 0.0f;
    }
    
    // Full constructor
    public HeatMapEntry(int id, int hour, int attempts, int successes, float successRate, String lastUpdated) {
        this.id = id;
        this.hour = hour;
        this.attempts = attempts;
        this.successes = successes;
        this.successRate = successRate;
        this.lastUpdated = lastUpdated;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getHour() {
        return hour;
    }
    
    public void setHour(int hour) {
        this.hour = hour;
    }
    
    public int getAttempts() {
        return attempts;
    }
    
    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }
    
    public int getSuccesses() {
        return successes;
    }
    
    public void setSuccesses(int successes) {
        this.successes = successes;
    }
    
    public float getSuccessRate() {
        return successRate;
    }
    
    public void setSuccessRate(float successRate) {
        this.successRate = successRate;
    }
    
    public String getLastUpdated() {
        return lastUpdated;
    }
    
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
    
    // Helper method to calculate success rate
    public float calculateSuccessRate() {
        if (attempts == 0) {
            return 0.0f;
        }
        return (float) successes / attempts * 100.0f; // Return percentage
    }
}