package com.tiktoktreasureauto;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.tiktoktreasureauto.models.HeatMapEntry;

import java.util.List;

public class HeatMapActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private GridLayout heatMapGrid;
    private Button resetButton;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_heat_map);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        heatMapGrid = findViewById(R.id.heatMapGrid);
        resetButton = findViewById(R.id.resetHeatMapButton);
        backButton = findViewById(R.id.backButton);

        // Set click listeners
        resetButton.setOnClickListener(v -> resetHeatMap());
        backButton.setOnClickListener(v -> finish());

        // Load and display heat map data
        loadHeatMapData();
    }

    /**
     * Load heat map data from database and display it
     */
    private void loadHeatMapData() {
        List<HeatMapEntry> entries = dbHelper.getAllHeatMapEntries();
        
        // Clear existing views in grid
        heatMapGrid.removeAllViews();
        
        // Add hour labels for top row
        for (int i = 0; i < 6; i++) {
            TextView hourLabel = new TextView(this);
            hourLabel.setText("");
            heatMapGrid.addView(hourLabel);
        }
        
        // Generate heat map cells
        for (int hour = 0; hour < 24; hour++) {
            // Add hour label at the beginning of each row if it's a multiple of 6
            if (hour % 6 == 0) {
                TextView hourLabel = new TextView(this);
                hourLabel.setText(formatHourLabel(hour));
                heatMapGrid.addView(hourLabel);
            }
            
            // Find the entry for this hour
            HeatMapEntry entry = findEntryForHour(entries, hour);
            
            // Create cell view
            View cellView = createHeatMapCell(entry);
            heatMapGrid.addView(cellView);
            
            // Add hour label at the end of each row if it's the last column
            if (hour % 6 == 5) {
                TextView hourLabel = new TextView(this);
                hourLabel.setText("");
                heatMapGrid.addView(hourLabel);
            }
        }
    }
    
    /**
     * Create a heat map cell view based on the entry data
     */
    private View createHeatMapCell(HeatMapEntry entry) {
        View cellView = new View(this);
        
        // Set cell size
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 120;
        params.height = 80;
        params.setMargins(4, 4, 4, 4);
        cellView.setLayoutParams(params);
        
        // Set cell color based on success rate
        int colorResId = getColorForSuccessRate(entry.getSuccessRate());
        cellView.setBackgroundColor(ContextCompat.getColor(this, colorResId));
        
        // Set tag with data for when clicked
        cellView.setTag(entry);
        
        // Set click listener to show details
        cellView.setOnClickListener(v -> {
            HeatMapEntry cellEntry = (HeatMapEntry) v.getTag();
            showCellDetails(cellEntry);
        });
        
        return cellView;
    }
    
    /**
     * Show details for a cell when clicked
     */
    private void showCellDetails(HeatMapEntry entry) {
        if (entry == null) return;
        
        String message = String.format(
            "Hour: %s\nSuccess Rate: %.1f%%\nSuccesses: %d\nAttempts: %d\nLast Updated: %s",
            formatHourLabel(entry.getHour()),
            entry.getSuccessRate(),
            entry.getSuccesses(),
            entry.getAttempts(),
            entry.getLastUpdated()
        );
        
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    
    /**
     * Get color resource ID based on success rate
     */
    private int getColorForSuccessRate(float successRate) {
        // Define color resource IDs for different success rate ranges
        if (successRate < 20) {
            return R.color.heat_map_level_1; // Lightest color - lowest success
        } else if (successRate < 40) {
            return R.color.heat_map_level_2;
        } else if (successRate < 60) {
            return R.color.heat_map_level_3;
        } else if (successRate < 80) {
            return R.color.heat_map_level_4;
        } else {
            return R.color.heat_map_level_5; // Darkest color - highest success
        }
    }
    
    /**
     * Format hour label (e.g., "6 AM", "3 PM")
     */
    private String formatHourLabel(int hour) {
        if (hour == 0) {
            return "12 AM";
        } else if (hour < 12) {
            return hour + " AM";
        } else if (hour == 12) {
            return "12 PM";
        } else {
            return (hour - 12) + " PM";
        }
    }
    
    /**
     * Find entry for a specific hour from the list
     */
    private HeatMapEntry findEntryForHour(List<HeatMapEntry> entries, int hour) {
        for (HeatMapEntry entry : entries) {
            if (entry.getHour() == hour) {
                return entry;
            }
        }
        // Should never happen since we initialize all 24 hours in database
        return new HeatMapEntry(hour);
    }
    
    /**
     * Reset heat map data
     */
    private void resetHeatMap() {
        dbHelper.resetHeatMap();
        Toast.makeText(this, "Heat map data has been reset", Toast.LENGTH_SHORT).show();
        loadHeatMapData(); // Reload the data
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        loadHeatMapData(); // Refresh data when returning to this activity
    }
}