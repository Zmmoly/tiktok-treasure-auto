package com.tiktoktreasureauto;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tiktoktreasureauto.adapters.LogAdapter;
import com.tiktoktreasureauto.database.DatabaseHelper;
import com.tiktoktreasureauto.models.LogEntry;
import com.tiktoktreasureauto.services.TikTokAccessibilityService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    
    // UI Elements
    private TextView statusTextView;
    private TextView boxesOpenedTextView;
    private TextView livesSkippedTextView;
    private TextView successRateTextView;
    private TextView runningTimeTextView;
    private TextView nextCheckTextView;
    private Button startStopButton;
    private Button accessibilitySettingsButton;
    private Button clearLogsButton;
    private EditText intervalEditText;
    private Switch autoRetrySwitch;
    private Switch notificationsSwitch;
    private RecyclerView logsRecyclerView;
    
    // Database Helper
    private DatabaseHelper dbHelper;
    
    // Log Adapter
    private LogAdapter logAdapter;
    
    // Handler for updating runtime
    private Handler handler = new Handler();
    private Runnable runtimeUpdater;
    
    // Log receiver
    private BroadcastReceiver logReceiver;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize database helper
        dbHelper = new DatabaseHelper(this);
        
        // Initialize UI elements
        statusTextView = findViewById(R.id.statusTextView);
        boxesOpenedTextView = findViewById(R.id.boxesOpenedTextView);
        livesSkippedTextView = findViewById(R.id.livesSkippedTextView);
        successRateTextView = findViewById(R.id.successRateTextView);
        runningTimeTextView = findViewById(R.id.runningTimeTextView);
        nextCheckTextView = findViewById(R.id.nextCheckTextView);
        startStopButton = findViewById(R.id.startStopButton);
        accessibilitySettingsButton = findViewById(R.id.accessibilitySettingsButton);
        clearLogsButton = findViewById(R.id.clearLogsButton);
        intervalEditText = findViewById(R.id.intervalEditText);
        autoRetrySwitch = findViewById(R.id.autoRetrySwitch);
        notificationsSwitch = findViewById(R.id.notificationsSwitch);
        logsRecyclerView = findViewById(R.id.logsRecyclerView);
        
        // Set up logs recycler view
        logsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<LogEntry> logs = dbHelper.getAllLogs();
        logAdapter = new LogAdapter(logs);
        logsRecyclerView.setAdapter(logAdapter);
        
        // Load settings
        intervalEditText.setText(String.valueOf(dbHelper.getCheckInterval()));
        autoRetrySwitch.setChecked(dbHelper.getAutoRetry());
        notificationsSwitch.setChecked(dbHelper.getNotifications());
        
        // Update statistics display
        updateStatisticsDisplay();
        
        // Set up runtime updater
        setupRuntimeUpdater();
        
        // Set up log receiver
        setupLogReceiver();
        
        // Set up button click listeners
        setupButtonListeners();
        
        // Check if accessibility service is enabled
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "Please enable the Accessibility Service to use this app", Toast.LENGTH_LONG).show();
        }
        
        // Check automation status
        updateAutomationStatus();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // Register the log receiver
        registerReceiver(logReceiver, new IntentFilter("com.tiktoktreasureauto.LOG_UPDATED"));
        
        // Start the runtime updater
        handler.post(runtimeUpdater);
        
        // Update the automation status
        updateAutomationStatus();
        
        // Update statistics display
        updateStatisticsDisplay();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the log receiver
        unregisterReceiver(logReceiver);
        
        // Stop the runtime updater
        handler.removeCallbacks(runtimeUpdater);
    }
    
    /**
     * Set up the runtime updater
     */
    private void setupRuntimeUpdater() {
        runtimeUpdater = new Runnable() {
            @Override
            public void run() {
                if (dbHelper.isAutomationRunning()) {
                    // Update the runtime display
                    long startTime = dbHelper.getStartTime();
                    if (startTime > 0) {
                        long currentTime = System.currentTimeMillis();
                        long elapsedMillis = currentTime - startTime;
                        
                        // Update the runtime in the database
                        int runtimeSeconds = (int) TimeUnit.MILLISECONDS.toSeconds(elapsedMillis);
                        dbHelper.updateRuntimeSeconds(runtimeSeconds);
                        
                        // Format the runtime for display
                        String formattedTime = formatRuntime(runtimeSeconds);
                        runningTimeTextView.setText(formattedTime);
                    }
                }
                
                // Schedule the next update
                handler.postDelayed(this, 1000); // Update every second
            }
        };
    }
    
    /**
     * Set up the log receiver
     */
    private void setupLogReceiver() {
        logReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // Refresh the logs
                List<LogEntry> logs = dbHelper.getAllLogs();
                logAdapter = new LogAdapter(logs);
                logsRecyclerView.setAdapter(logAdapter);
                logsRecyclerView.scrollToPosition(0); // Scroll to the newest log
                
                // Update statistics
                updateStatisticsDisplay();
            }
        };
    }
    
    /**
     * Set up button click listeners
     */
    private void setupButtonListeners() {
        // Start/Stop button
        startStopButton.setOnClickListener(v -> {
            if (dbHelper.isAutomationRunning()) {
                stopAutomation();
            } else {
                startAutomation();
            }
        });
        
        // Accessibility Settings button
        accessibilitySettingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
        });
        
        // Clear Logs button
        clearLogsButton.setOnClickListener(v -> {
            dbHelper.clearLogs();
            List<LogEntry> logs = dbHelper.getAllLogs();
            logAdapter = new LogAdapter(logs);
            logsRecyclerView.setAdapter(logAdapter);
            Toast.makeText(this, "Logs cleared", Toast.LENGTH_SHORT).show();
        });
        
        // Heat Map button
        Button heatMapButton = findViewById(R.id.heatMapButton);
        heatMapButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HeatMapActivity.class);
            startActivity(intent);
        });
        
        // Settings button
        Button settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
        
        // Save settings when interval is changed
        intervalEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                try {
                    int interval = Integer.parseInt(intervalEditText.getText().toString());
                    if (interval < 1) {
                        interval = 1;
                        intervalEditText.setText(String.valueOf(interval));
                    }
                    dbHelper.updateCheckInterval(interval);
                } catch (NumberFormatException e) {
                    intervalEditText.setText(String.valueOf(dbHelper.getCheckInterval()));
                }
            }
        });
        
        // Save settings when auto retry is toggled
        autoRetrySwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            dbHelper.updateAutoRetry(isChecked);
        });
        
        // Save settings when notifications is toggled
        notificationsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            dbHelper.updateNotifications(isChecked);
        });
    }
    
    /**
     * Update the statistics display
     */
    private void updateStatisticsDisplay() {
        // Update boxes opened
        int boxesOpened = dbHelper.getBoxesOpened();
        boxesOpenedTextView.setText(String.valueOf(boxesOpened));
        
        // Update lives skipped
        int livesSkipped = dbHelper.getLivesSkipped();
        livesSkippedTextView.setText(String.valueOf(livesSkipped));
        
        // Calculate success rate (if any boxes have been attempted)
        if (boxesOpened + livesSkipped > 0) {
            int successRatePercent = (int) ((float) boxesOpened / (boxesOpened + livesSkipped) * 100);
            successRateTextView.setText(successRatePercent + "%");
        } else {
            successRateTextView.setText("0%");
        }
        
        // Update runtime
        int runtimeSeconds = dbHelper.getRuntimeSeconds();
        String formattedTime = formatRuntime(runtimeSeconds);
        runningTimeTextView.setText(formattedTime);
        
        // Update next check time
        long nextCheckTime = dbHelper.getNextCheckTime();
        if (nextCheckTime > 0 && dbHelper.isAutomationRunning()) {
            SimpleDateFormat format = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String formattedNextCheck = format.format(new Date(nextCheckTime));
            nextCheckTextView.setText(formattedNextCheck);
        } else {
            nextCheckTextView.setText("--:--");
        }
    }
    
    /**
     * Format runtime in seconds to HH:MM:SS
     */
    private String formatRuntime(int seconds) {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int secs = seconds % 60;
        
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs);
    }
    
    /**
     * Update the automation status display
     */
    private void updateAutomationStatus() {
        boolean isRunning = dbHelper.isAutomationRunning();
        
        if (isRunning) {
            statusTextView.setText("Running");
            statusTextView.setTextColor(getResources().getColor(R.color.colorSuccess));
            startStopButton.setText("Stop Automation");
            startStopButton.setBackgroundColor(getResources().getColor(R.color.colorError));
        } else {
            statusTextView.setText("Stopped");
            statusTextView.setTextColor(getResources().getColor(R.color.colorError));
            startStopButton.setText("Start Automation");
            startStopButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        }
    }
    
    /**
     * Start the automation
     */
    private void startAutomation() {
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "Please enable the Accessibility Service first", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            return;
        }
        
        // Get the TikTok Accessibility Service
        Intent serviceIntent = new Intent(this, TikTokAccessibilityService.class);
        startService(serviceIntent);
        
        // Update the database
        dbHelper.updateAutomationStatus(true);
        dbHelper.updateStartTime(System.currentTimeMillis());
        
        // Update the interval in case it was changed
        try {
            int interval = Integer.parseInt(intervalEditText.getText().toString());
            if (interval < 1) {
                interval = 1;
                intervalEditText.setText(String.valueOf(interval));
            }
            dbHelper.updateCheckInterval(interval);
        } catch (NumberFormatException e) {
            intervalEditText.setText(String.valueOf(dbHelper.getCheckInterval()));
        }
        
        // Update the UI
        updateAutomationStatus();
        
        // Start the runtime updater
        handler.post(runtimeUpdater);
        
        // Send a broadcast to start the service
        Intent broadcastIntent = new Intent("com.tiktoktreasureauto.START_AUTOMATION");
        sendBroadcast(broadcastIntent);
    }
    
    /**
     * Stop the automation
     */
    private void stopAutomation() {
        // Send a broadcast to stop the service
        Intent broadcastIntent = new Intent("com.tiktoktreasureauto.STOP_AUTOMATION");
        sendBroadcast(broadcastIntent);
        
        // Update the database
        dbHelper.updateAutomationStatus(false);
        
        // Update the UI
        updateAutomationStatus();
    }
    
    /**
     * Check if the accessibility service is enabled
     */
    private boolean isAccessibilityServiceEnabled() {
        String serviceName = getPackageName() + "/" + TikTokAccessibilityService.class.getCanonicalName();
        String enabledServices = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        
        return enabledServices != null && enabledServices.contains(serviceName);
    }
}