package com.tiktoktreasureauto.services;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.tiktoktreasureauto.database.DatabaseHelper;
import com.tiktoktreasureauto.models.LogEntry;
import com.tiktoktreasureauto.NotificationManager;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Accessibility Service to automate TikTok treasure box opening
 */
public class TikTokAccessibilityService extends AccessibilityService {
    
    private static final String TIKTOK_PACKAGE = "com.zhiliaoapp.musically";
    private static final String TREASURE_BOX_TEXT = "Treasure Box";
    private static final String OPEN_TEXT = "Open";
    private static final String LIVE_VIEWER_COUNT_REGEX = "(\\d+)\\s*viewers";
    private static final String TREASURE_BOX_COUNT_REGEX = "(\\d+)\\s*boxes";
    
    private boolean isRunning = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    private DatabaseHelper dbHelper;
    private NotificationManager notificationManager;
    
    @Override
    public void onCreate() {
        super.onCreate();
        dbHelper = new DatabaseHelper(this);
        // Get notification preference from settings
        boolean notificationsEnabled = dbHelper.getNotificationsEnabled();
        notificationManager = new NotificationManager(this, notificationsEnabled);
    }
    
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!isRunning) return;
        
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;
        
        try {
            // Check if we're in a TikTok live screen
            if (isInTikTokLive(rootNode)) {
                // Check if there are any treasure boxes
                if (!hasTreasureBoxes(rootNode)) {
                    skipToNextLive("No treasure boxes available");
                    return;
                }
                
                // Check viewer to treasure box ratio
                if (shouldSkipLive(rootNode)) {
                    skipToNextLive("High viewer-to-box ratio");
                    return;
                }
                
                // Look for treasure box
                findAndClickTreasureBox(rootNode);
            }
        } finally {
            rootNode.recycle();
        }
    }
    
    /**
     * Determines if we're currently in a TikTok live stream
     */
    private boolean isInTikTokLive(AccessibilityNodeInfo rootNode) {
        List<AccessibilityNodeInfo> liveNodes = rootNode.findAccessibilityNodeInfosByText("LIVE");
        boolean isLive = !liveNodes.isEmpty();
        
        // Recycle nodes to prevent memory leaks
        for (AccessibilityNodeInfo node : liveNodes) {
            node.recycle();
        }
        
        return isLive;
    }
    
    /**
     * Checks if the live stream has any treasure boxes
     */
    private boolean hasTreasureBoxes(AccessibilityNodeInfo rootNode) {
        List<AccessibilityNodeInfo> boxNodes = new ArrayList<>();
        // Look for text that contains "boxes" or "Treasure Box"
        findNodesByTextPattern(rootNode, "boxes", boxNodes);
        findNodesByTextPattern(rootNode, TREASURE_BOX_TEXT, boxNodes);
        
        boolean hasBoxes = !boxNodes.isEmpty();
        
        // Recycle all nodes
        for (AccessibilityNodeInfo node : boxNodes) {
            node.recycle();
        }
        
        return hasBoxes;
    }
    
    /**
     * Checks if we should skip this live based on viewer to box ratio
     * Returns true if ratio is GREATER THAN minimum ratio (default 2.0)
     * This means we STAY in lives with FEW viewers per box and SKIP lives with MANY viewers per box
     */
    private boolean shouldSkipLive(AccessibilityNodeInfo rootNode) {
        // Get viewer count
        int viewerCount = getViewerCount(rootNode);
        
        // Get treasure box count
        int boxCount = getTreasureBoxCount(rootNode);
        
        // If we couldn't determine the counts, don't skip
        if (viewerCount == -1 || boxCount == -1 || boxCount == 0) {
            return false;
        }
        
        // Calculate ratio: viewers per box
        float ratio = (float) viewerCount / boxCount;
        
        // Get minimum ratio from settings
        float minRatio = dbHelper.getMinimumViewerRatio();
        
        // Log the ratio for debugging
        addLog(String.format("Live has %d viewers and %d boxes. Ratio: %.2f (Max preferred: %.2f)", 
                viewerCount, boxCount, ratio, minRatio), "info");
        
        // Skip if ratio is GREATER than our preferred maximum
        // This means we stay in lives with small viewer to box ratio and skip lives with high ratio
        return ratio > minRatio;
    }
    
    /**
     * Extract viewer count from live stream
     */
    private int getViewerCount(AccessibilityNodeInfo rootNode) {
        List<AccessibilityNodeInfo> viewerNodes = new ArrayList<>();
        // Look for text that contains "viewers"
        findNodesByTextPattern(rootNode, "viewers", viewerNodes);
        
        for (AccessibilityNodeInfo node : viewerNodes) {
            String text = node.getText() != null ? node.getText().toString() : "";
            Pattern pattern = Pattern.compile(LIVE_VIEWER_COUNT_REGEX);
            Matcher matcher = pattern.matcher(text);
            
            if (matcher.find()) {
                try {
                    int count = Integer.parseInt(matcher.group(1).replaceAll(",", ""));
                    // Recycle all nodes
                    for (AccessibilityNodeInfo n : viewerNodes) {
                        n.recycle();
                    }
                    return count;
                } catch (NumberFormatException e) {
                    // Continue to next node if parsing fails
                }
            }
        }
        
        // Recycle all nodes
        for (AccessibilityNodeInfo node : viewerNodes) {
            node.recycle();
        }
        
        return -1; // Could not determine viewer count
    }
    
    /**
     * Extract treasure box count from live stream
     */
    private int getTreasureBoxCount(AccessibilityNodeInfo rootNode) {
        List<AccessibilityNodeInfo> boxNodes = new ArrayList<>();
        // Look for text that contains "boxes" or "Treasure Box"
        findNodesByTextPattern(rootNode, "boxes", boxNodes);
        findNodesByTextPattern(rootNode, TREASURE_BOX_TEXT, boxNodes);
        
        for (AccessibilityNodeInfo node : boxNodes) {
            String text = node.getText() != null ? node.getText().toString() : "";
            Pattern pattern = Pattern.compile(TREASURE_BOX_COUNT_REGEX);
            Matcher matcher = pattern.matcher(text);
            
            if (matcher.find()) {
                try {
                    int count = Integer.parseInt(matcher.group(1));
                    // Recycle all nodes
                    for (AccessibilityNodeInfo n : boxNodes) {
                        n.recycle();
                    }
                    return count;
                } catch (NumberFormatException e) {
                    // Continue to next node if parsing fails
                }
            }
        }
        
        // Check if there's just a single box without a count
        if (!boxNodes.isEmpty()) {
            for (AccessibilityNodeInfo node : boxNodes) {
                node.recycle();
            }
            return 1; // Assume one box if we found TREASURE_BOX_TEXT but no count
        }
        
        // Recycle all nodes
        for (AccessibilityNodeInfo node : boxNodes) {
            node.recycle();
        }
        
        return -1; // Could not determine box count
    }
    
    /**
     * Find nodes that match a specific text pattern
     */
    private void findNodesByTextPattern(AccessibilityNodeInfo node, String pattern, List<AccessibilityNodeInfo> result) {
        if (node == null) return;
        
        if (node.getText() != null && node.getText().toString().toLowerCase().contains(pattern.toLowerCase())) {
            result.add(node.obtainCopy());
        }
        
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                findNodesByTextPattern(child, pattern, result);
                child.recycle();
            }
        }
    }
    
    /**
     * Skip to the next live stream
     */
    private void skipToNextLive() {
        // Swipe up to go to next live
        performSwipeUp();
        
        // Update stats in DB
        dbHelper.incrementLivesSkipped();
    }
    
    /**
     * Skip to the next live stream with a log message
     */
    private void skipToNextLive(String reason) {
        // Log the action with the specific reason
        addLog("Moved to next live stream: " + reason, "info");
        
        // Send notification if needed
        if (notificationManager != null) {
            notificationManager.notifyLiveSkipped(reason);
        }
        
        // Skip to next live
        skipToNextLive();
    }
    
    /**
     * Perform a swipe up gesture to move to next live
     */
    private void performSwipeUp() {
        // Get screen dimensions
        Rect screenRect = new Rect();
        getRootInActiveWindow().getBoundsInScreen(screenRect);
        
        int screenHeight = screenRect.height();
        int screenWidth = screenRect.width();
        
        // Calculate swipe coordinates
        int startX = screenWidth / 2;
        int startY = (int) (screenHeight * 0.7);
        int endX = startX;
        int endY = (int) (screenHeight * 0.3);
        
        // Create swipe path
        android.accessibilityservice.GestureDescription.Builder builder = 
                new android.accessibilityservice.GestureDescription.Builder();
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(startX, startY);
        path.lineTo(endX, endY);
        
        builder.addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(
                path, 0, 300)); // 300ms duration
        
        // Perform the gesture
        dispatchGesture(builder.build(), null, null);
    }
    
    /**
     * Find and click on treasure box
     */
    private void findAndClickTreasureBox(AccessibilityNodeInfo rootNode) {
        // Find treasure box node
        List<AccessibilityNodeInfo> treasureBoxNodes = rootNode.findAccessibilityNodeInfosByText(TREASURE_BOX_TEXT);
        
        if (!treasureBoxNodes.isEmpty()) {
            // Found treasure box, try to click it
            boolean clicked = false;
            
            for (AccessibilityNodeInfo node : treasureBoxNodes) {
                if (node.isClickable()) {
                    clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    if (clicked) {
                        addLog("Found and clicked treasure box", "success");
                        handleOpenButton();
                        break;
                    }
                } else {
                    // Try to find clickable parent
                    AccessibilityNodeInfo parent = node;
                    while (parent != null && !parent.isClickable()) {
                        AccessibilityNodeInfo temp = parent.getParent();
                        if (parent != node) {
                            parent.recycle();
                        }
                        parent = temp;
                    }
                    
                    if (parent != null && parent.isClickable()) {
                        clicked = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        if (clicked) {
                            addLog("Found and clicked treasure box (via parent)", "success");
                            handleOpenButton();
                        }
                        if (parent != node) {
                            parent.recycle();
                        }
                        if (clicked) break;
                    }
                }
            }
            
            if (!clicked) {
                addLog("Found treasure box but couldn't click it", "warning");
                // Record failed treasure box attempt for heat map
                dbHelper.recordBoxAttempt(false);
            }
        }
        
        // Recycle all nodes
        for (AccessibilityNodeInfo node : treasureBoxNodes) {
            node.recycle();
        }
    }
    
    /**
     * Handle clicking the open button after treasure box is clicked
     */
    private void handleOpenButton() {
        // Add a small delay to wait for the open button to appear
        handler.postDelayed(() -> {
            AccessibilityNodeInfo rootNode = getRootInActiveWindow();
            if (rootNode == null) return;
            
            try {
                List<AccessibilityNodeInfo> openButtons = rootNode.findAccessibilityNodeInfosByText(OPEN_TEXT);
                
                boolean clicked = false;
                for (AccessibilityNodeInfo button : openButtons) {
                    if (button.isClickable()) {
                        clicked = button.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        if (clicked) {
                            addLog("Opened treasure box successfully", "success");
                            dbHelper.incrementBoxesOpened();
                            // Record successful treasure box attempt for heat map
                            dbHelper.recordBoxAttempt(true);
                            if (notificationManager != null) {
                                notificationManager.notifyBoxOpened();
                            }
                            break;
                        }
                    } else {
                        // Try to find clickable parent
                        AccessibilityNodeInfo parent = button;
                        while (parent != null && !parent.isClickable()) {
                            AccessibilityNodeInfo temp = parent.getParent();
                            if (parent != button) {
                                parent.recycle();
                            }
                            parent = temp;
                        }
                        
                        if (parent != null && parent.isClickable()) {
                            clicked = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            if (clicked) {
                                addLog("Opened treasure box successfully (via parent)", "success");
                                dbHelper.incrementBoxesOpened();
                                // Record successful treasure box attempt for heat map
                                dbHelper.recordBoxAttempt(true);
                                if (notificationManager != null) {
                                    notificationManager.notifyBoxOpened();
                                }
                            }
                            if (parent != button) {
                                parent.recycle();
                            }
                            if (clicked) break;
                        }
                    }
                }
                
                if (!clicked && !openButtons.isEmpty()) {
                    addLog("Found open button but couldn't click it", "warning");
                    // Record failed treasure box attempt for heat map
                    dbHelper.recordBoxAttempt(false);
                }
                
                // Recycle all nodes
                for (AccessibilityNodeInfo button : openButtons) {
                    button.recycle();
                }
                
            } finally {
                rootNode.recycle();
            }
        }, 1000); // 1 second delay
    }
    
    /**
     * Add log entry to database
     */
    private void addLog(String message, String type) {
        LogEntry logEntry = new LogEntry(message, type);
        dbHelper.addLog(logEntry);
        
        // Broadcast log update to MainActivity
        Intent intent = new Intent("com.tiktoktreasureauto.LOG_UPDATED");
        intent.putExtra("message", message);
        intent.putExtra("type", type);
        sendBroadcast(intent);
    }
    
    /**
     * Start automation
     */
    public void startAutomation() {
        isRunning = true;
        addLog("Automation started", "info");
        dbHelper.updateAutomationStatus(true);
        
        // Launch TikTok if not already running
        launchTikTok();
    }
    
    /**
     * Stop automation
     */
    public void stopAutomation() {
        isRunning = false;
        addLog("Automation stopped", "info");
        dbHelper.updateAutomationStatus(false);
    }
    
    /**
     * Launch TikTok app
     */
    private void launchTikTok() {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(TIKTOK_PACKAGE);
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launchIntent);
            addLog("Launched TikTok", "info");
        } else {
            addLog("TikTok app not found on device", "error");
        }
    }
    
    @Override
    public void onInterrupt() {
        // Service interrupted
        addLog("Accessibility service interrupted", "warning");
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        addLog("Accessibility service destroyed", "warning");
        isRunning = false;
        dbHelper.updateAutomationStatus(false);
    }
    
    @Override
    protected boolean onKeyEvent(android.view.KeyEvent event) {
        // Handle key events if needed
        return super.onKeyEvent(event);
    }
}