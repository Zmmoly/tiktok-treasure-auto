package com.tiktoktreasureauto.models;

/**
 * Model for log entries
 */
public class LogEntry {
    private int id;
    private String message;
    private String type;  // "info", "success", "warning", "error"
    private String timestamp;
    
    public LogEntry() {
        // Default constructor
    }
    
    public LogEntry(String message, String type) {
        this.message = message;
        this.type = type;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}