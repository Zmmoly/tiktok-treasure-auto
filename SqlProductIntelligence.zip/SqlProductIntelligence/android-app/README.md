# TikTok Treasure Auto

An advanced Android application for automated TikTok treasure box optimization, leveraging intelligent stream analysis and multi-account management to maximize reward collection efficiency.

## Key Features

- **Automated Treasure Box Opening**: Automatically detects and opens treasure boxes in TikTok live streams
- **Intelligent Stream Selection**: Analyzes viewer-to-box ratios to prioritize streams with lower competition
- **Success Rate Heat Map**: Visualizes your treasure box opening success rate by hour of day
- **Scheduling System**: Configure custom check intervals, rest periods, and stream limits
- **Multi-language Support**: Includes Arabic language detection
- **Persistent Storage**: Tracks all statistics, logs, and settings in a local SQLite database
- **Background Operation**: Runs in the background with minimal battery usage
- **Auto-restart**: Can optionally restart on device boot

## Technical Implementation

- Uses Android's Accessibility Service API to detect and interact with TikTok's UI elements
- Implements a heat map visualization to show success rates by hour and day type
- Uses SQLite database for persistent storage of statistics and settings
- Provides detailed logging and notification system
- Implements optimized algorithms to prioritize streams with lower viewer counts

## Installation

1. Download the APK file from the `/android-app/build/output/tiktok-treasure-auto.apk` path
2. Install the APK on your Android device
3. Grant the required permissions (Accessibility Service, Notifications)
4. Configure your settings in the app
5. Start the automation

## Permissions Required

- `BIND_ACCESSIBILITY_SERVICE`: To detect and interact with TikTok UI elements
- `INTERNET`: For connecting to TikTok servers
- `FOREGROUND_SERVICE`: To run as a background service
- `WAKE_LOCK`: To prevent the device from sleeping during operation
- `RECEIVE_BOOT_COMPLETED`: To start automatically after device boot (optional)
- `SYSTEM_ALERT_WINDOW`: To display overlays for certain notifications
- `POST_NOTIFICATIONS`: To show notifications about treasure box activity

## Components

- `MainActivity`: Main UI for controlling the application
- `TikTokAccessibilityService`: Core service that monitors and interacts with TikTok
- `DatabaseHelper`: Manages SQLite database operations
- `HeatMapActivity`: Visualizes success rate patterns
- `BackgroundService`: Manages the lifecycle of the automation service
- `BootReceiver`: Handles auto-start on device boot

## Configuration Options

- **Check Interval**: Time between treasure box checks (1-30 minutes)
- **Streams Before Rest**: Number of streams to check before taking a break (1-20 streams)
- **Rest Duration**: How long to rest between checking sessions (1-30 minutes)

## Building from Source

The project uses Gradle as its build system. To build from source:

1. Clone the repository
2. Open the project in Android Studio
3. Build using Gradle: `./gradlew assembleDebug`
4. The APK will be generated in the `app/build/outputs/apk/debug/` directory

## License

This project is licensed under the MIT License - see the LICENSE file for details.