import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Switch,
  StatusBar,
} from 'react-native';

// Main App component
const App = () => {
  // States for the application
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState([]);
  const [statistics, setStatistics] = useState({
    boxesOpened: 0,
    successRate: '0%',
    runningTime: '00:00:00',
    nextCheck: '--:--',
  });
  const [settings, setSettings] = useState({
    interval: 15,
    autoRetry: true,
    notifications: true,
  });
  const [detectionStatus, setDetectionStatus] = useState({
    tikTokInterface: false,
    accessibilityAccess: false,
    treasureBox: null,
    clickEvents: false,
  });

  // Mock function to add a log entry
  const addLogEntry = (message, type) => {
    const newLog = {
      id: Date.now(),
      timestamp: new Date(),
      message,
      type,
    };
    setLogs([newLog, ...logs].slice(0, 100)); // Keep only the most recent 100 logs
  };

  // Start automation function
  const startAutomation = () => {
    if (!detectionStatus.accessibilityAccess) {
      addLogEntry('Accessibility permission is required to run the automation', 'error');
      return;
    }
    
    setIsRunning(true);
    addLogEntry('Automation started', 'info');
    // In a real app, this would start the accessibility service
  };

  // Stop automation function
  const stopAutomation = () => {
    setIsRunning(false);
    addLogEntry('Automation stopped', 'info');
    // In a real app, this would stop the accessibility service
  };

  // Update settings function
  const updateSettings = (newSettings) => {
    setSettings({ ...settings, ...newSettings });
    addLogEntry('Settings updated', 'info');
  };

  // Clear logs function
  const clearLogs = () => {
    setLogs([]);
    addLogEntry('Logs cleared', 'info');
  };

  // Effects for initial setup
  useEffect(() => {
    // This would check for permissions and initialize the app
    addLogEntry('Application initialized', 'info');
    addLogEntry('Please enable Accessibility Services for TikTok Treasure Box Automation', 'warning');
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f5f5f5" />
      
      <View style={styles.header}>
        <Text style={styles.title}>TikTok Treasure Box Automation</Text>
      </View>
      
      <ScrollView style={styles.content}>
        {/* Status Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Status</Text>
          <View style={styles.statusContainer}>
            <Text style={styles.statusLabel}>Running:</Text>
            <Text style={[
              styles.statusValue, 
              isRunning ? styles.statusRunning : styles.statusStopped
            ]}>
              {isRunning ? 'Active' : 'Stopped'}
            </Text>
          </View>
          
          <View style={styles.buttonGroup}>
            <TouchableOpacity 
              style={[styles.button, isRunning ? styles.stopButton : styles.startButton]}
              onPress={isRunning ? stopAutomation : startAutomation}
            >
              <Text style={styles.buttonText}>
                {isRunning ? 'Stop Automation' : 'Start Automation'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Statistics Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Statistics</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Boxes Opened:</Text>
              <Text style={styles.statValue}>{statistics.boxesOpened}</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Success Rate:</Text>
              <Text style={styles.statValue}>{statistics.successRate}</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Running Time:</Text>
              <Text style={styles.statValue}>{statistics.runningTime}</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Next Check:</Text>
              <Text style={styles.statValue}>{statistics.nextCheck}</Text>
            </View>
          </View>
        </View>
        
        {/* Settings Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Check Interval (minutes):</Text>
              <View style={styles.intervalControls}>
                <TouchableOpacity 
                  style={styles.intervalButton}
                  onPress={() => updateSettings({ interval: Math.max(1, settings.interval - 1) })}
                >
                  <Text style={styles.intervalButtonText}>-</Text>
                </TouchableOpacity>
                <Text style={styles.intervalValue}>{settings.interval}</Text>
                <TouchableOpacity 
                  style={styles.intervalButton}
                  onPress={() => updateSettings({ interval: settings.interval + 1 })}
                >
                  <Text style={styles.intervalButtonText}>+</Text>
                </TouchableOpacity>
              </View>
            </View>
            
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Auto Retry:</Text>
              <Switch
                value={settings.autoRetry}
                onValueChange={(value) => updateSettings({ autoRetry: value })}
                trackColor={{ false: "#767577", true: "#4CAF50" }}
                thumbColor={settings.autoRetry ? "#fff" : "#f4f3f4"}
              />
            </View>
            
            <View style={styles.settingItem}>
              <Text style={styles.settingLabel}>Notifications:</Text>
              <Switch
                value={settings.notifications}
                onValueChange={(value) => updateSettings({ notifications: value })}
                trackColor={{ false: "#767577", true: "#4CAF50" }}
                thumbColor={settings.notifications ? "#fff" : "#f4f3f4"}
              />
            </View>
          </View>
        </View>
        
        {/* Logs Section */}
        <View style={styles.section}>
          <View style={styles.logHeader}>
            <Text style={styles.sectionTitle}>Activity Logs</Text>
            <TouchableOpacity style={styles.clearButton} onPress={clearLogs}>
              <Text style={styles.clearButtonText}>Clear</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.logsContainer}>
            {logs.length === 0 ? (
              <Text style={styles.emptyLogs}>No logs yet</Text>
            ) : (
              logs.map((log) => (
                <View 
                  key={log.id} 
                  style={[
                    styles.logItem, 
                    log.type === 'error' ? styles.errorLog :
                    log.type === 'warning' ? styles.warningLog :
                    log.type === 'success' ? styles.successLog :
                    styles.infoLog
                  ]}
                >
                  <Text style={styles.logTime}>
                    {log.timestamp.toLocaleTimeString()}
                  </Text>
                  <Text style={styles.logMessage}>{log.message}</Text>
                </View>
              ))
            )}
          </View>
        </View>
        
        {/* Setup Guide Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Setup Guide</Text>
          <View style={styles.guideContainer}>
            <Text style={styles.guideTitle}>1. Enable Accessibility Service</Text>
            <Text style={styles.guideText}>
              Go to Settings → Accessibility → Installed Services → TikTok Treasure Box Automation → Turn On
            </Text>
            
            <Text style={styles.guideTitle}>2. Enable Auto-Start (Optional)</Text>
            <Text style={styles.guideText}>
              For uninterrupted automation, allow the app to auto-start in your phone's settings.
            </Text>
            
            <Text style={styles.guideTitle}>3. Battery Optimization</Text>
            <Text style={styles.guideText}>
              Disable battery optimization for this app in your device settings to ensure it can run in the background.
            </Text>
            
            <Text style={styles.guideTitle}>4. Use TikTok Account</Text>
            <Text style={styles.guideText}>
              Make sure you're logged into your TikTok account on your device.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 15,
    backgroundColor: '#1DA1F2',
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  content: {
    flex: 1,
    padding: 10,
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 8,
    marginBottom: 15,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  statusLabel: {
    fontSize: 16,
    color: '#555',
    marginRight: 10,
  },
  statusValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  statusRunning: {
    color: '#4CAF50',
  },
  statusStopped: {
    color: '#F44336',
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 200,
  },
  startButton: {
    backgroundColor: '#4CAF50',
  },
  stopButton: {
    backgroundColor: '#F44336',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  statsContainer: {
    marginBottom: 10,
  },
  statItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  statLabel: {
    fontSize: 14,
    color: '#555',
  },
  statValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  settingsContainer: {
    marginBottom: 10,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  settingLabel: {
    fontSize: 14,
    color: '#555',
  },
  intervalControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  intervalButton: {
    width: 30,
    height: 30,
    backgroundColor: '#1DA1F2',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  intervalButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  intervalValue: {
    marginHorizontal: 15,
    fontSize: 16,
    fontWeight: 'bold',
  },
  logHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  clearButton: {
    backgroundColor: '#FF5722',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  clearButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  logsContainer: {
    maxHeight: 200,
  },
  emptyLogs: {
    textAlign: 'center',
    color: '#888',
    fontStyle: 'italic',
    padding: 20,
  },
  logItem: {
    flexDirection: 'row',
    padding: 8,
    borderRadius: 5,
    marginBottom: 5,
  },
  errorLog: {
    backgroundColor: '#FFEBEE',
  },
  warningLog: {
    backgroundColor: '#FFF8E1',
  },
  successLog: {
    backgroundColor: '#E8F5E9',
  },
  infoLog: {
    backgroundColor: '#E3F2FD',
  },
  logTime: {
    color: '#555',
    fontSize: 12,
    marginRight: 8,
  },
  logMessage: {
    flex: 1,
    fontSize: 12,
    color: '#333',
  },
  guideContainer: {
    marginBottom: 10,
  },
  guideTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#1DA1F2',
    marginTop: 10,
    marginBottom: 5,
  },
  guideText: {
    fontSize: 14,
    color: '#555',
    marginBottom: 10,
  },
});

export default App;