package com.tiktoktreasureauto.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tiktoktreasureauto.R;
import com.tiktoktreasureauto.models.LogEntry;

import java.util.List;

/**
 * Adapter for displaying logs in a RecyclerView
 */
public class LogAdapter extends RecyclerView.Adapter<LogAdapter.LogViewHolder> {
    
    private final List<LogEntry> logs;
    
    /**
     * Constructor
     */
    public LogAdapter(List<LogEntry> logs) {
        this.logs = logs;
    }
    
    @NonNull
    @Override
    public LogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_log, parent, false);
        return new LogViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull LogViewHolder holder, int position) {
        LogEntry log = logs.get(position);
        
        // Set the time
        holder.timeTextView.setText(log.getFormattedTime());
        
        // Set the message
        holder.messageTextView.setText(log.getMessage());
        
        // Set the background color based on log type
        switch (log.getType()) {
            case "error":
                holder.itemView.setBackgroundColor(Color.parseColor("#FFEBEE")); // Light red
                break;
            case "warning":
                holder.itemView.setBackgroundColor(Color.parseColor("#FFF8E1")); // Light yellow
                break;
            case "success":
                holder.itemView.setBackgroundColor(Color.parseColor("#E8F5E9")); // Light green
                break;
            default: // info
                holder.itemView.setBackgroundColor(Color.parseColor("#E3F2FD")); // Light blue
                break;
        }
    }
    
    @Override
    public int getItemCount() {
        return logs.size();
    }
    
    /**
     * ViewHolder for log entries
     */
    static class LogViewHolder extends RecyclerView.ViewHolder {
        TextView timeTextView;
        TextView messageTextView;
        
        LogViewHolder(View itemView) {
            super(itemView);
            timeTextView = itemView.findViewById(R.id.timeTextView);
            messageTextView = itemView.findViewById(R.id.messageTextView);
        }
    }
}