package com.tiktoktreasureauto;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

/**
 * Handles notifications for the app
 */
public class NotificationManager {
    private static final String NOTIFICATION_CHANNEL_ID = "tiktok_automation_channel";
    private static final String NOTIFICATION_CHANNEL_NAME = "TikTok Automation";
    private static final int NOTIFICATION_ID_BOX_OPENED = 1001;
    private static final int NOTIFICATION_ID_SKIPPED = 1002;
    
    private Context context;
    private android.app.NotificationManager notificationManager;
    private boolean notificationsEnabled;
    
    public NotificationManager(Context context, boolean notificationsEnabled) {
        this.context = context;
        this.notificationsEnabled = notificationsEnabled;
        this.notificationManager = (android.app.NotificationManager) 
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        
        // Create notification channel for Android 8.0+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    NOTIFICATION_CHANNEL_NAME,
                    android.app.NotificationManager.IMPORTANCE_DEFAULT);
            
            notificationManager.createNotificationChannel(channel);
        }
    }
    
    // Set notification enabled state
    public void setNotificationsEnabled(boolean enabled) {
        this.notificationsEnabled = enabled;
    }
    
    // Send notification about a found and opened treasure box
    public void notifyBoxOpened() {
        if (!notificationsEnabled) return;
        
        // Intent to open the app when notification is tapped
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        
        Notification notification = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("تم فتح صندوق الكنز")
                .setContentText("تم العثور على صندوق كنز TikTok وفتحه بنجاح!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();
        
        notificationManager.notify(NOTIFICATION_ID_BOX_OPENED, notification);
    }
    
    // Send notification about a skipped live stream
    public void notifyLiveSkipped(String reason) {
        if (!notificationsEnabled) return;
        
        String notificationText;
        
        if (reason.contains("No treasure boxes")) {
            notificationText = "تخطي البث: لا توجد صناديق متاحة";
        } else if (reason.contains("High viewer-to-box ratio")) {
            notificationText = "تخطي البث: نسبة المشاهدين للصناديق مرتفعة جدًا";
        } else {
            notificationText = "تم تخطي البث: " + reason;
        }
        
        Notification notification = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("تم تخطي البث المباشر")
                .setContentText(notificationText)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build();
        
        notificationManager.notify(NOTIFICATION_ID_SKIPPED, notification);
    }
}