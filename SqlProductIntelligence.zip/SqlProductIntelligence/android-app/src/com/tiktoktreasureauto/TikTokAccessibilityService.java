package com.tiktoktreasureauto;

import android.accessibilityservice.AccessibilityService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import androidx.core.app.NotificationCompat;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TikTokAccessibilityService extends AccessibilityService {

    private static final String TAG = "TikTokAccessibility";
    private static final String TIKTOK_PACKAGE = "com.ss.android.ugc.trill";
    private static final String TIKTOK_ALT_PACKAGE = "com.zhiliaoapp.musically";
    private static final String TREASURE_BOX_ID = "treasure_box";
    private static final String LIVE_VIEWER_COUNT_ID = "viewer_count";
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL_ID = "TikTokTreasureChannel";

    private DatabaseHelper dbHelper;
    private Handler handler = new Handler(Looper.getMainLooper());
    private AtomicBoolean isRunning = new AtomicBoolean(false);
    private AtomicBoolean isSearching = new AtomicBoolean(false);
    private int consecutiveStreamsWithoutBox = 0;
    private int streamsCheckedInSession = 0;
    private int maxStreamsBeforeRest = 5;
    private int restDurationMinutes = 5;
    
    private boolean isArabicLocale = false;

    @Override
    public void onCreate() {
        super.onCreate();
        dbHelper = new DatabaseHelper(this);
        
        // Check if device locale is Arabic
        isArabicLocale = Locale.getDefault().getLanguage().equals("ar");
        
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case "START_MONITORING":
                    startMonitoring(
                            intent.getIntExtra("streamsBeforeRest", 5),
                            intent.getIntExtra("restDuration", 5)
                    );
                    break;
                case "STOP_MONITORING":
                    stopMonitoring();
                    break;
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopMonitoring();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!isRunning.get() || event == null || event.getSource() == null) {
            return;
        }

        // Check if we're in TikTok app
        String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";
        if (!packageName.equals(TIKTOK_PACKAGE) && !packageName.equals(TIKTOK_ALT_PACKAGE)) {
            return;
        }

        // Process the event based on type
        switch (event.getEventType()) {
            case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                if (isSearching.get()) {
                    checkForTreasureBox(event.getSource());
                }
                break;
        }
    }

    @Override
    public void onInterrupt() {
        stopMonitoring();
    }

    private void startMonitoring(int streamsBeforeRest, int restDuration) {
        if (isRunning.get()) {
            return; // Already running
        }
        
        isRunning.set(true);
        maxStreamsBeforeRest = streamsBeforeRest;
        restDurationMinutes = restDuration;
        consecutiveStreamsWithoutBox = 0;
        streamsCheckedInSession = 0;
        
        logInfo("Starting TikTok Treasure Box monitoring");
        showNotification("Monitoring Started", "Looking for treasure boxes in streams");
        startCheckingForTreasure();
    }

    private void stopMonitoring() {
        isRunning.set(false);
        isSearching.set(false);
        handler.removeCallbacksAndMessages(null);
        logInfo("Monitoring stopped");
        
        // Remove foreground notification
        stopForeground(true);
    }

    private void startCheckingForTreasure() {
        isSearching.set(true);
        handler.postDelayed(() -> {
            if (!isRunning.get()) {
                return;
            }
            
            logInfo("Checking for treasure box in current stream");
            AccessibilityNodeInfo rootNode = getRootInActiveWindow();
            if (rootNode != null) {
                checkForTreasureBox(rootNode);
            }
        }, 1000); // Small delay to ensure screen is loaded
    }

    private void checkForTreasureBox(AccessibilityNodeInfo rootNode) {
        if (rootNode == null) {
            return;
        }

        try {
            // Try to find treasure box view by ID
            List<AccessibilityNodeInfo> treasureNodes = rootNode.findAccessibilityNodeInfosByViewId(
                    getCurrentPackageName() + ":id/" + TREASURE_BOX_ID);
            
            if (!treasureNodes.isEmpty()) {
                // Found treasure box!
                logSuccess("Found treasure box! Attempting to open...");
                showNotification("Treasure Found!", "Attempting to open a treasure box");
                
                // Get viewer count before clicking
                int viewerCount = getViewerCount(rootNode);
                
                // Click on the treasure box
                treasureNodes.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
                
                // Record successful opening in database
                recordTreasureBoxOpening(true, viewerCount);
                
                // Reset counter since we found a box
                consecutiveStreamsWithoutBox = 0;
                
                // Increment statistics
                dbHelper.incrementBoxesOpened();
                
                // Schedule next check
                scheduleNextCheck(true);
            } else {
                logInfo("No treasure box found in this stream");
                
                // Check if we should stay in this stream or move to the next one
                int viewerCount = getViewerCount(rootNode);
                if (shouldStayInCurrentStream(viewerCount)) {
                    logInfo("Low viewer count detected, staying in this stream and waiting for treasure box");
                    scheduleNextCheck(false);
                } else {
                    logWarning("Stream doesn't have a treasure box and has high viewer count, skipping");
                    consecutiveStreamsWithoutBox++;
                    
                    // Record failed attempt
                    recordTreasureBoxOpening(false, viewerCount);
                    
                    // Increment streams checked counter
                    dbHelper.incrementStreamsChecked();
                    streamsCheckedInSession++;
                    
                    // Check if we need to take a rest
                    if (streamsCheckedInSession >= maxStreamsBeforeRest) {
                        logInfo("Taking a break after checking " + streamsCheckedInSession + " streams");
                        showNotification("Taking a Break", 
                                "Checked " + streamsCheckedInSession + " streams. Resuming in " + restDurationMinutes + " minutes");
                        
                        // Reset counter
                        streamsCheckedInSession = 0;
                        
                        // Schedule next check after rest period
                        handler.postDelayed(this::navigateToNextStream, restDurationMinutes * 60 * 1000);
                    } else {
                        // Navigate to next stream
                        navigateToNextStream();
                    }
                }
            }
        } catch (Exception e) {
            logError("Error checking for treasure box: " + e.getMessage());
        } finally {
            rootNode.recycle();
        }
    }
    
    private boolean shouldStayInCurrentStream(int viewerCount) {
        // Logic to determine if we should stay in the current stream
        // Low viewer count streams might be more likely to get treasure boxes with less competition
        
        // If viewer count is very low (e.g., under 50), stay in the stream
        if (viewerCount < 50) {
            return true;
        }
        
        // If viewer count is moderate (under 200) and we've already skipped several streams, stay
        if (viewerCount < 200 && consecutiveStreamsWithoutBox > 5) {
            return true;
        }
        
        // Otherwise, move to next stream
        return false;
    }
    
    private int getViewerCount(AccessibilityNodeInfo rootNode) {
        try {
            List<AccessibilityNodeInfo> viewerNodes = rootNode.findAccessibilityNodeInfosByViewId(
                    getCurrentPackageName() + ":id/" + LIVE_VIEWER_COUNT_ID);
            
            if (!viewerNodes.isEmpty() && viewerNodes.get(0).getText() != null) {
                String viewerText = viewerNodes.get(0).getText().toString();
                return parseViewerCount(viewerText);
            }
        } catch (Exception e) {
            logError("Error getting viewer count: " + e.getMessage());
        }
        
        return -1; // Unknown viewer count
    }
    
    private int parseViewerCount(String viewerText) {
        try {
            // Handle different formats (e.g., "1.2K viewers", "1200", etc.)
            Pattern pattern = Pattern.compile("([\\d\\.]+)([KkMm])?");
            Matcher matcher = pattern.matcher(viewerText);
            
            if (matcher.find()) {
                double number = Double.parseDouble(matcher.group(1));
                String multiplier = matcher.group(2);
                
                if (multiplier != null) {
                    if (multiplier.equalsIgnoreCase("k")) {
                        number *= 1000;
                    } else if (multiplier.equalsIgnoreCase("m")) {
                        number *= 1000000;
                    }
                }
                
                return (int) number;
            }
        } catch (Exception e) {
            logError("Error parsing viewer count: " + e.getMessage());
        }
        
        return -1;
    }
    
    private void navigateToNextStream() {
        if (!isRunning.get()) {
            return;
        }
        
        logInfo("Navigating to next stream");
        
        // Simulate swipe up to navigate to next stream
        performGlobalSwipe();
        
        // Schedule check after a delay to allow new content to load
        handler.postDelayed(this::startCheckingForTreasure, 2000);
    }
    
    private void performGlobalSwipe() {
        // This is a complex operation that depends on device size
        // In a real application, you would use GestureDescription for API level 24+ 
        // For demo purposes, we'll just log the action
        logInfo("Swiping to next stream");
        
        // For actual implementation, use:
        // GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
        // Path path = new Path();
        // path.moveTo(displayWidth / 2, displayHeight * 3 / 4);
        // path.lineTo(displayWidth / 2, displayHeight / 4);
        // gestureBuilder.addStroke(new GestureDescription.StrokeDescription(path, 100, 50));
        // dispatchGesture(gestureBuilder.build(), null, null);
    }
    
    private void scheduleNextCheck(boolean foundBox) {
        if (!isRunning.get()) {
            return;
        }
        
        int delay = foundBox ? 30000 : 10000; // 30 seconds after finding box, 10 seconds otherwise
        
        handler.postDelayed(() -> {
            if (isRunning.get()) {
                startCheckingForTreasure();
            }
        }, delay);
    }
    
    private void recordTreasureBoxOpening(boolean success, int viewerCount) {
        // Record this attempt in the heat map
        dbHelper.recordBoxOpening(success);
        
        // Add to log
        String message = success 
                ? "Successfully opened treasure box" + (viewerCount > 0 ? " (Viewers: " + viewerCount + ")" : "")
                : "No treasure box found" + (viewerCount > 0 ? " (Viewers: " + viewerCount + ")" : "");
        
        dbHelper.addLog(message, success ? "success" : "info");
    }
    
    private String getCurrentPackageName() {
        // Check which TikTok package is currently active
        return TIKTOK_PACKAGE; // For simplicity, always return the primary package
    }
    
    private void logInfo(String message) {
        Log.i(TAG, message);
        dbHelper.addLog(message, "info");
    }
    
    private void logSuccess(String message) {
        Log.i(TAG, message);
        dbHelper.addLog(message, "success");
    }
    
    private void logWarning(String message) {
        Log.w(TAG, message);
        dbHelper.addLog(message, "warning");
    }
    
    private void logError(String message) {
        Log.e(TAG, message);
        dbHelper.addLog(message, "error");
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription(getString(R.string.notification_channel_description));
            channel.enableLights(true);
            channel.setLightColor(Color.BLUE);
            
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    
    private void showNotification(String title, String content) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(content)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                .build();
        
        startForeground(NOTIFICATION_ID, notification);
    }
}