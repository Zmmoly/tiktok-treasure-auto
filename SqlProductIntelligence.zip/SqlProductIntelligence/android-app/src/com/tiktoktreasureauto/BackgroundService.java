package com.tiktoktreasureauto;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class BackgroundService extends Service {
    
    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    
    private static final int NOTIFICATION_ID = 1002;
    private static final String CHANNEL_ID = "TikTokTreasureServiceChannel";
    
    private static boolean isServiceRunning = false;
    private static String currentAction = null;
    
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            
            switch (action) {
                case ACTION_START:
                    startTreasureService(intent);
                    break;
                    
                case ACTION_STOP:
                    stopTreasureService();
                    break;
            }
        }
        
        return START_STICKY;
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopTreasureService();
    }
    
    private void startTreasureService(Intent intent) {
        if (isServiceRunning) {
            return;
        }
        
        // Get settings from intent
        int checkInterval = intent.getIntExtra("checkInterval", 5);
        int streamsBeforeRest = intent.getIntExtra("streamsBeforeRest", 5);
        int restDuration = intent.getIntExtra("restDuration", 5);
        
        // Start foreground service with notification
        Notification notification = createNotification("TikTok Treasure Auto is running",
                "Monitoring TikTok live streams for treasure boxes");
        startForeground(NOTIFICATION_ID, notification);
        
        // Start the accessibility service
        Intent accessibilityIntent = new Intent(this, TikTokAccessibilityService.class);
        accessibilityIntent.setAction("START_MONITORING");
        accessibilityIntent.putExtra("streamsBeforeRest", streamsBeforeRest);
        accessibilityIntent.putExtra("restDuration", restDuration);
        startService(accessibilityIntent);
        
        // Update state
        isServiceRunning = true;
        currentAction = "Searching for treasure boxes";
        
        // Log the action
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addLog("Service started with interval: " + checkInterval + 
                "min, streams before rest: " + streamsBeforeRest +
                ", rest duration: " + restDuration + "min", "info");
    }
    
    private void stopTreasureService() {
        // Stop the accessibility service
        Intent accessibilityIntent = new Intent(this, TikTokAccessibilityService.class);
        accessibilityIntent.setAction("STOP_MONITORING");
        startService(accessibilityIntent);
        
        // Update state
        isServiceRunning = false;
        currentAction = null;
        
        // Log the action
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addLog("Service stopped", "info");
        
        // Stop foreground service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
        
        stopSelf();
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "TikTok Treasure Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }
    
    private Notification createNotification(String title, String content) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(content)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                .build();
    }
    
    public static boolean isRunning() {
        return isServiceRunning;
    }
    
    public static String getCurrentAction() {
        return currentAction;
    }
    
    public static void setCurrentAction(String action) {
        currentAction = action;
    }
}