package com.tiktoktreasureauto;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogEntry {
    private int id;
    private long timestamp;
    private String message;
    private String type;

    public LogEntry() {
    }

    public LogEntry(int id, long timestamp, String message, String type) {
        this.id = id;
        this.timestamp = timestamp;
        this.message = message;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFormattedTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    public int getTypeColor() {
        switch (type) {
            case "info":
                return R.color.log_info;
            case "success":
                return R.color.log_success;
            case "warning":
                return R.color.log_warning;
            case "error":
                return R.color.log_error;
            default:
                return R.color.log_info;
        }
    }
}