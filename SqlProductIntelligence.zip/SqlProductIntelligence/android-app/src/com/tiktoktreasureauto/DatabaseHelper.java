package com.tiktoktreasureauto;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tiktok_treasure.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    private static final String TABLE_LOGS = "logs";
    private static final String TABLE_STATISTICS = "statistics";
    private static final String TABLE_SETTINGS = "settings";
    private static final String TABLE_SUCCESS_HEATMAP = "success_heatmap";

    // Common column names
    private static final String KEY_ID = "id";
    private static final String KEY_TIMESTAMP = "timestamp";

    // Logs table columns
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_TYPE = "type";

    // Statistics table columns
    private static final String KEY_BOXES_OPENED = "boxes_opened";
    private static final String KEY_STREAMS_CHECKED = "streams_checked";

    // Settings table columns
    private static final String KEY_CHECK_INTERVAL = "check_interval";
    private static final String KEY_STREAMS_BEFORE_REST = "streams_before_rest";
    private static final String KEY_REST_DURATION = "rest_duration";

    // Heat map table columns
    private static final String KEY_HOUR = "hour";
    private static final String KEY_DAY_OF_WEEK = "day_of_week";
    private static final String KEY_SUCCESS_COUNT = "success_count";
    private static final String KEY_ATTEMPT_COUNT = "attempt_count";
    private static final String KEY_IS_WEEKDAY = "is_weekday";
    private static final String KEY_IS_PEAK_HOUR = "is_peak_hour";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create logs table
        String CREATE_LOGS_TABLE = "CREATE TABLE " + TABLE_LOGS + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_TIMESTAMP + " INTEGER,"
                + KEY_MESSAGE + " TEXT,"
                + KEY_TYPE + " TEXT"
                + ")";
        db.execSQL(CREATE_LOGS_TABLE);

        // Create statistics table
        String CREATE_STATISTICS_TABLE = "CREATE TABLE " + TABLE_STATISTICS + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_BOXES_OPENED + " INTEGER DEFAULT 0,"
                + KEY_STREAMS_CHECKED + " INTEGER DEFAULT 0"
                + ")";
        db.execSQL(CREATE_STATISTICS_TABLE);

        // Create settings table
        String CREATE_SETTINGS_TABLE = "CREATE TABLE " + TABLE_SETTINGS + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_CHECK_INTERVAL + " INTEGER DEFAULT 5,"
                + KEY_STREAMS_BEFORE_REST + " INTEGER DEFAULT 5,"
                + KEY_REST_DURATION + " INTEGER DEFAULT 5"
                + ")";
        db.execSQL(CREATE_SETTINGS_TABLE);

        // Create heat map table
        String CREATE_HEATMAP_TABLE = "CREATE TABLE " + TABLE_SUCCESS_HEATMAP + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_HOUR + " INTEGER,"
                + KEY_DAY_OF_WEEK + " INTEGER,"
                + KEY_SUCCESS_COUNT + " INTEGER DEFAULT 0,"
                + KEY_ATTEMPT_COUNT + " INTEGER DEFAULT 0,"
                + KEY_IS_WEEKDAY + " INTEGER DEFAULT 0,"
                + KEY_IS_PEAK_HOUR + " INTEGER DEFAULT 0"
                + ")";
        db.execSQL(CREATE_HEATMAP_TABLE);

        // Insert default settings
        ContentValues settingsValues = new ContentValues();
        settingsValues.put(KEY_ID, 1);
        settingsValues.put(KEY_CHECK_INTERVAL, 5);
        settingsValues.put(KEY_STREAMS_BEFORE_REST, 5);
        settingsValues.put(KEY_REST_DURATION, 5);
        db.insert(TABLE_SETTINGS, null, settingsValues);

        // Insert default statistics
        ContentValues statisticsValues = new ContentValues();
        statisticsValues.put(KEY_ID, 1);
        statisticsValues.put(KEY_BOXES_OPENED, 0);
        statisticsValues.put(KEY_STREAMS_CHECKED, 0);
        db.insert(TABLE_STATISTICS, null, statisticsValues);

        // Initialize heat map data for all hours
        initializeHeatMapData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STATISTICS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SUCCESS_HEATMAP);

        // Create tables again
        onCreate(db);
    }

    private void initializeHeatMapData(SQLiteDatabase db) {
        // Initialize heat map entries for all hours
        for (int hour = 0; hour < 24; hour++) {
            // Weekday entry
            ContentValues weekdayValues = new ContentValues();
            weekdayValues.put(KEY_HOUR, hour);
            weekdayValues.put(KEY_DAY_OF_WEEK, -1); // -1 for aggregated weekday
            weekdayValues.put(KEY_SUCCESS_COUNT, 0);
            weekdayValues.put(KEY_ATTEMPT_COUNT, 0);
            weekdayValues.put(KEY_IS_WEEKDAY, 1);
            weekdayValues.put(KEY_IS_PEAK_HOUR, isPeakHour(hour) ? 1 : 0);
            db.insert(TABLE_SUCCESS_HEATMAP, null, weekdayValues);

            // Weekend entry
            ContentValues weekendValues = new ContentValues();
            weekendValues.put(KEY_HOUR, hour);
            weekendValues.put(KEY_DAY_OF_WEEK, -2); // -2 for aggregated weekend
            weekendValues.put(KEY_SUCCESS_COUNT, 0);
            weekendValues.put(KEY_ATTEMPT_COUNT, 0);
            weekendValues.put(KEY_IS_WEEKDAY, 0);
            weekendValues.put(KEY_IS_PEAK_HOUR, isPeakHour(hour) ? 1 : 0);
            db.insert(TABLE_SUCCESS_HEATMAP, null, weekendValues);

            // All days entry
            ContentValues allDaysValues = new ContentValues();
            allDaysValues.put(KEY_HOUR, hour);
            allDaysValues.put(KEY_DAY_OF_WEEK, -3); // -3 for all days
            allDaysValues.put(KEY_SUCCESS_COUNT, 0);
            allDaysValues.put(KEY_ATTEMPT_COUNT, 0);
            allDaysValues.put(KEY_IS_WEEKDAY, 2); // 2 for both weekday and weekend
            allDaysValues.put(KEY_IS_PEAK_HOUR, isPeakHour(hour) ? 1 : 0);
            db.insert(TABLE_SUCCESS_HEATMAP, null, allDaysValues);
        }
    }

    private boolean isPeakHour(int hour) {
        // Define peak hours (e.g., evening hours from 7PM to 10PM)
        return hour >= 19 && hour <= 22;
    }

    // Log operations
    public void addLog(String message, String type) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TIMESTAMP, System.currentTimeMillis());
        values.put(KEY_MESSAGE, message);
        values.put(KEY_TYPE, type);
        db.insert(TABLE_LOGS, null, values);
        db.close();
    }

    public List<LogEntry> getLogs(int limit) {
        List<LogEntry> logs = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_LOGS + " ORDER BY " + KEY_TIMESTAMP + " DESC LIMIT " + limit;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                LogEntry log = new LogEntry();
                log.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID)));
                log.setTimestamp(cursor.getLong(cursor.getColumnIndex(KEY_TIMESTAMP)));
                log.setMessage(cursor.getString(cursor.getColumnIndex(KEY_MESSAGE)));
                log.setType(cursor.getString(cursor.getColumnIndex(KEY_TYPE)));
                logs.add(log);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return logs;
    }

    public void clearLogs() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_LOGS, null, null);
        db.close();
    }

    // Statistics operations
    public int getBoxesOpened() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_STATISTICS, new String[]{KEY_BOXES_OPENED}, KEY_ID + "=?", new String[]{"1"}, null, null, null);
        int boxesOpened = 0;
        if (cursor.moveToFirst()) {
            boxesOpened = cursor.getInt(cursor.getColumnIndex(KEY_BOXES_OPENED));
        }
        cursor.close();
        db.close();
        return boxesOpened;
    }

    public int getStreamsChecked() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_STATISTICS, new String[]{KEY_STREAMS_CHECKED}, KEY_ID + "=?", new String[]{"1"}, null, null, null);
        int streamsChecked = 0;
        if (cursor.moveToFirst()) {
            streamsChecked = cursor.getInt(cursor.getColumnIndex(KEY_STREAMS_CHECKED));
        }
        cursor.close();
        db.close();
        return streamsChecked;
    }

    public void incrementBoxesOpened() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_BOXES_OPENED, getBoxesOpened() + 1);
        db.update(TABLE_STATISTICS, values, KEY_ID + "=?", new String[]{"1"});
        db.close();
    }

    public void incrementStreamsChecked() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_STREAMS_CHECKED, getStreamsChecked() + 1);
        db.update(TABLE_STATISTICS, values, KEY_ID + "=?", new String[]{"1"});
        db.close();
    }

    // Heat map operations
    public void recordBoxOpening(boolean success) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        boolean isWeekday = dayOfWeek != Calendar.SATURDAY && dayOfWeek != Calendar.SUNDAY;

        SQLiteDatabase db = this.getWritableDatabase();

        // Update specific day entry (not implemented in this demo)

        // Update weekday/weekend entries
        String weekdayType = isWeekday ? "-1" : "-2"; // -1 for weekday, -2 for weekend
        incrementHeatMapEntry(db, hour, weekdayType, success);

        // Update all days entry
        incrementHeatMapEntry(db, hour, "-3", success);

        db.close();
    }

    private void incrementHeatMapEntry(SQLiteDatabase db, int hour, String dayType, boolean success) {
        // Get current values
        Cursor cursor = db.query(TABLE_SUCCESS_HEATMAP, 
                new String[]{KEY_SUCCESS_COUNT, KEY_ATTEMPT_COUNT},
                KEY_HOUR + "=? AND " + KEY_DAY_OF_WEEK + "=?",
                new String[]{String.valueOf(hour), dayType},
                null, null, null);

        int successCount = 0;
        int attemptCount = 0;

        if (cursor.moveToFirst()) {
            successCount = cursor.getInt(cursor.getColumnIndex(KEY_SUCCESS_COUNT));
            attemptCount = cursor.getInt(cursor.getColumnIndex(KEY_ATTEMPT_COUNT));
        }
        cursor.close();

        // Update values
        ContentValues values = new ContentValues();
        values.put(KEY_ATTEMPT_COUNT, attemptCount + 1);
        if (success) {
            values.put(KEY_SUCCESS_COUNT, successCount + 1);
        }

        db.update(TABLE_SUCCESS_HEATMAP, values,
                KEY_HOUR + "=? AND " + KEY_DAY_OF_WEEK + "=?",
                new String[]{String.valueOf(hour), dayType});
    }

    public List<HeatMapEntry> getHeatMapData() {
        List<HeatMapEntry> heatMapEntries = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_SUCCESS_HEATMAP;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                HeatMapEntry entry = new HeatMapEntry();
                entry.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID)));
                entry.setHour(cursor.getInt(cursor.getColumnIndex(KEY_HOUR)));
                entry.setDayOfWeek(cursor.getInt(cursor.getColumnIndex(KEY_DAY_OF_WEEK)));
                entry.setSuccessCount(cursor.getInt(cursor.getColumnIndex(KEY_SUCCESS_COUNT)));
                entry.setAttemptCount(cursor.getInt(cursor.getColumnIndex(KEY_ATTEMPT_COUNT)));
                entry.setWeekday(cursor.getInt(cursor.getColumnIndex(KEY_IS_WEEKDAY)) == 1);
                entry.setPeakHour(cursor.getInt(cursor.getColumnIndex(KEY_IS_PEAK_HOUR)) == 1);
                heatMapEntries.add(entry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return heatMapEntries;
    }
}