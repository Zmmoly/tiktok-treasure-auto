package com.tiktoktreasureauto;

import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.gridlayout.widget.GridLayout;

import java.util.List;

public class HeatMapActivity extends AppCompatActivity {

    private GridLayout heatMapGrid;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_heat_map);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize views
        heatMapGrid = findViewById(R.id.heatMapGrid);

        // Generate heat map
        generateHeatMap();
    }

    private void generateHeatMap() {
        // Get heat map data from database
        List<HeatMapEntry> heatMapData = dbHelper.getHeatMapData();

        // Define column labels (hours 0-23)
        String[] columnLabels = {"0-3", "4-7", "8-11", "12-15", "16-19", "20-23"};

        // Define row labels (days of week)
        String[] rowLabels = {"Weekday", "Weekend", "All Days", "Peak Hours"};

        // Clear existing views
        heatMapGrid.removeAllViews();

        // Add column headers
        for (int i = 0; i < columnLabels.length; i++) {
            TextView header = createHeaderTextView(columnLabels[i]);
            GridLayout.Spec rowSpec = GridLayout.spec(0);
            GridLayout.Spec colSpec = GridLayout.spec(i + 1, 1f);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams(rowSpec, colSpec);
            heatMapGrid.addView(header, params);
        }

        // Add row headers
        for (int i = 0; i < rowLabels.length; i++) {
            TextView header = createHeaderTextView(rowLabels[i]);
            GridLayout.Spec rowSpec = GridLayout.spec(i + 1);
            GridLayout.Spec colSpec = GridLayout.spec(0);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams(rowSpec, colSpec);
            heatMapGrid.addView(header, params);
        }

        // Add heat map cells
        for (int row = 0; row < rowLabels.length; row++) {
            for (int col = 0; col < columnLabels.length; col++) {
                CardView cell = createHeatMapCell(row, col, heatMapData);
                GridLayout.Spec rowSpec = GridLayout.spec(row + 1);
                GridLayout.Spec colSpec = GridLayout.spec(col + 1, 1f);
                GridLayout.LayoutParams params = new GridLayout.LayoutParams(rowSpec, colSpec);
                params.width = 0;
                params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                params.setMargins(4, 4, 4, 4);
                heatMapGrid.addView(cell, params);
            }
        }
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(8, 8, 8, 8);
        textView.setTextColor(getResources().getColor(R.color.colorText));
        return textView;
    }

    private CardView createHeatMapCell(int row, int col, List<HeatMapEntry> heatMapData) {
        CardView cardView = new CardView(this);
        cardView.setCardElevation(2);
        cardView.setRadius(8);
        
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(8, 8, 8, 8);
        container.setGravity(Gravity.CENTER);
        
        // Calculate time period based on column
        int startHour = col * 4;
        int endHour = startHour + 3;
        
        // Get data for this cell
        HeatMapEntry entry = findHeatMapEntry(row, startHour, endHour, heatMapData);
        
        // Set background color based on success rate
        int colorResId;
        if (entry == null || (entry.getAttemptCount() == 0)) {
            colorResId = R.color.heatmap_no_data;
        } else {
            float successRate = (float) entry.getSuccessCount() / entry.getAttemptCount() * 100;
            if (successRate >= 80) {
                colorResId = R.color.heatmap_highest;
            } else if (successRate >= 60) {
                colorResId = R.color.heatmap_high;
            } else if (successRate >= 40) {
                colorResId = R.color.heatmap_medium;
            } else if (successRate >= 20) {
                colorResId = R.color.heatmap_low;
            } else {
                colorResId = R.color.heatmap_lowest;
            }
        }
        cardView.setCardBackgroundColor(getResources().getColor(colorResId));
        
        // Add data text views
        TextView rateText = new TextView(this);
        if (entry == null || entry.getAttemptCount() == 0) {
            rateText.setText(getString(R.string.no_data));
        } else {
            float successRate = (float) entry.getSuccessCount() / entry.getAttemptCount() * 100;
            rateText.setText(String.format(getString(R.string.rate_value), successRate));
        }
        rateText.setTextSize(16);
        rateText.setTextColor(getResources().getColor(R.color.colorText));
        rateText.setGravity(Gravity.CENTER);
        
        TextView detailText = new TextView(this);
        if (entry == null) {
            detailText.setText("");
        } else {
            detailText.setText(String.format("%d/%d", entry.getSuccessCount(), entry.getAttemptCount()));
        }
        detailText.setTextSize(12);
        detailText.setTextColor(getResources().getColor(R.color.colorTextSecondary));
        detailText.setGravity(Gravity.CENTER);
        
        container.addView(rateText);
        container.addView(detailText);
        cardView.addView(container);
        
        return cardView;
    }

    private HeatMapEntry findHeatMapEntry(int row, int startHour, int endHour, List<HeatMapEntry> heatMapData) {
        // In a real app, this would filter data based on row (day type) and hour range
        // For this demo, we'll just return mock data based on position
        
        // Find matching entries in the data list
        for (HeatMapEntry entry : heatMapData) {
            boolean hourMatch = entry.getHour() >= startHour && entry.getHour() <= endHour;
            boolean typeMatch = false;
            
            switch (row) {
                case 0: // Weekday
                    typeMatch = entry.isWeekday();
                    break;
                case 1: // Weekend
                    typeMatch = !entry.isWeekday();
                    break;
                case 2: // All days
                    typeMatch = true;
                    break;
                case 3: // Peak hours
                    typeMatch = entry.isPeakHour();
                    break;
            }
            
            if (hourMatch && typeMatch) {
                return entry;
            }
        }
        
        return null;
    }
}