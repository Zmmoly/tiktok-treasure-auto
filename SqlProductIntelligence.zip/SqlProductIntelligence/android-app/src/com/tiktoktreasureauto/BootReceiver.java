package com.tiktoktreasureauto;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null && intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            // Check if we need to automatically start the service on boot
            SharedPreferences prefs = context.getSharedPreferences("TikTokTreasureSettings", Context.MODE_PRIVATE);
            boolean startOnBoot = prefs.getBoolean("startOnBoot", false);
            
            if (startOnBoot) {
                // Get saved settings
                int checkInterval = prefs.getInt("checkInterval", 5);
                int streamsBeforeRest = prefs.getInt("streamsBeforeRest", 5);
                int restDuration = prefs.getInt("restDuration", 5);
                
                // Create intent to start the service
                Intent serviceIntent = new Intent(context, BackgroundService.class);
                serviceIntent.setAction(BackgroundService.ACTION_START);
                serviceIntent.putExtra("checkInterval", checkInterval);
                serviceIntent.putExtra("streamsBeforeRest", streamsBeforeRest);
                serviceIntent.putExtra("restDuration", restDuration);
                
                // Start the service
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
                
                // Log this event
                DatabaseHelper dbHelper = new DatabaseHelper(context);
                dbHelper.addLog("Service started automatically after device boot", "info");
            }
        }
    }
}