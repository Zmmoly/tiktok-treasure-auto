package com.tiktoktreasureauto;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus, tvCurrentAction, tvBoxesOpened, tvStreamsChecked, tvSuccessRate;
    private TextView tvCheckInterval, tvStreamsBeforeRest, tvRestDuration;
    private Button btnStart, btnStop, btnHeatMap, btnClearLogs;
    private SeekBar sbCheckInterval, sbStreamsBeforeRest, sbRestDuration;
    private RecyclerView rvLogs;
    private LogAdapter logAdapter;

    private DatabaseHelper dbHelper;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize preferences
        preferences = getSharedPreferences("TikTokTreasureSettings", MODE_PRIVATE);

        // Initialize UI components
        initializeViews();
        setupListeners();
        
        // Load saved settings
        loadSettings();
        
        // Load statistics
        updateStatistics();
        
        // Load logs
        loadLogs();
        
        // Check if accessibility service is enabled
        if (!isAccessibilityServiceEnabled()) {
            showAccessibilityDialog();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateServiceStatus();
        updateStatistics();
        loadLogs();
    }

    private void initializeViews() {
        tvStatus = findViewById(R.id.tvStatus);
        tvCurrentAction = findViewById(R.id.tvCurrentAction);
        tvBoxesOpened = findViewById(R.id.tvBoxesOpened);
        tvStreamsChecked = findViewById(R.id.tvStreamsChecked);
        tvSuccessRate = findViewById(R.id.tvSuccessRate);
        tvCheckInterval = findViewById(R.id.tvCheckInterval);
        tvStreamsBeforeRest = findViewById(R.id.tvStreamsBeforeRest);
        tvRestDuration = findViewById(R.id.tvRestDuration);
        
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        btnHeatMap = findViewById(R.id.btnHeatMap);
        btnClearLogs = findViewById(R.id.btnClearLogs);
        
        sbCheckInterval = findViewById(R.id.sbCheckInterval);
        sbStreamsBeforeRest = findViewById(R.id.sbStreamsBeforeRest);
        sbRestDuration = findViewById(R.id.sbRestDuration);
        
        rvLogs = findViewById(R.id.rvLogs);
        rvLogs.setLayoutManager(new LinearLayoutManager(this));
        logAdapter = new LogAdapter();
        rvLogs.setAdapter(logAdapter);
    }

    private void setupListeners() {
        btnStart.setOnClickListener(v -> startService());
        btnStop.setOnClickListener(v -> stopService());
        btnHeatMap.setOnClickListener(v -> openHeatMap());
        btnClearLogs.setOnClickListener(v -> clearLogs());
        
        // Set up seek bar listeners
        sbCheckInterval.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int interval = progress + 1; // Minimum 1 minute
                tvCheckInterval.setText(interval + " minutes");
                saveSettings();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        sbStreamsBeforeRest.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int streams = progress + 1; // Minimum 1 stream
                tvStreamsBeforeRest.setText(streams + " streams");
                saveSettings();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        sbRestDuration.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int duration = progress + 1; // Minimum 1 minute
                tvRestDuration.setText(duration + " minutes");
                saveSettings();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void loadSettings() {
        int checkInterval = preferences.getInt("checkInterval", 5);
        int streamsBeforeRest = preferences.getInt("streamsBeforeRest", 5);
        int restDuration = preferences.getInt("restDuration", 5);
        
        sbCheckInterval.setProgress(checkInterval - 1);
        sbStreamsBeforeRest.setProgress(streamsBeforeRest - 1);
        sbRestDuration.setProgress(restDuration - 1);
        
        tvCheckInterval.setText(checkInterval + " minutes");
        tvStreamsBeforeRest.setText(streamsBeforeRest + " streams");
        tvRestDuration.setText(restDuration + " minutes");
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("checkInterval", sbCheckInterval.getProgress() + 1);
        editor.putInt("streamsBeforeRest", sbStreamsBeforeRest.getProgress() + 1);
        editor.putInt("restDuration", sbRestDuration.getProgress() + 1);
        editor.apply();
    }

    private void updateStatistics() {
        int boxesOpened = dbHelper.getBoxesOpened();
        int streamsChecked = dbHelper.getStreamsChecked();
        float successRate = streamsChecked > 0 ? ((float) boxesOpened / streamsChecked) * 100 : 0;
        
        tvBoxesOpened.setText(String.valueOf(boxesOpened));
        tvStreamsChecked.setText(String.valueOf(streamsChecked));
        tvSuccessRate.setText(String.format("%.1f%%", successRate));
    }

    private void loadLogs() {
        List<LogEntry> logs = dbHelper.getLogs(50); // Get last 50 logs
        logAdapter.setLogs(logs);
    }

    private void clearLogs() {
        dbHelper.clearLogs();
        loadLogs();
        Toast.makeText(this, "Logs cleared", Toast.LENGTH_SHORT).show();
    }

    private void startService() {
        if (!isAccessibilityServiceEnabled()) {
            showAccessibilityDialog();
            return;
        }
        
        Intent intent = new Intent(this, BackgroundService.class);
        intent.setAction(BackgroundService.ACTION_START);
        intent.putExtra("checkInterval", sbCheckInterval.getProgress() + 1);
        intent.putExtra("streamsBeforeRest", sbStreamsBeforeRest.getProgress() + 1);
        intent.putExtra("restDuration", sbRestDuration.getProgress() + 1);
        startService(intent);
        
        updateServiceStatus();
    }

    private void stopService() {
        Intent intent = new Intent(this, BackgroundService.class);
        intent.setAction(BackgroundService.ACTION_STOP);
        startService(intent);
        
        updateServiceStatus();
    }

    private void updateServiceStatus() {
        boolean isRunning = BackgroundService.isRunning();
        
        tvStatus.setText(isRunning ? R.string.service_running : R.string.service_stopped);
        tvStatus.setTextColor(getResources().getColor(isRunning ? R.color.status_running : R.color.status_stopped));
        
        String currentAction = BackgroundService.getCurrentAction();
        tvCurrentAction.setText("Current action: " + (currentAction != null ? currentAction : "None"));
        
        btnStart.setEnabled(!isRunning);
        btnStop.setEnabled(isRunning);
    }

    private void openHeatMap() {
        Intent intent = new Intent(this, HeatMapActivity.class);
        startActivity(intent);
    }

    private boolean isAccessibilityServiceEnabled() {
        String service = getPackageName() + "/" + TikTokAccessibilityService.class.getCanonicalName();
        String enabledServices = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabledServices != null && enabledServices.contains(service);
    }

    private void showAccessibilityDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.enable_accessibility)
                .setMessage("TikTok Treasure Auto needs accessibility permissions to function. Please enable it in settings.")
                .setPositiveButton(R.string.open_settings, (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}