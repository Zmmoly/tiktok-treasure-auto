package com.tiktoktreasureauto;

public class HeatMapEntry {
    private int id;
    private int hour;
    private int dayOfWeek;
    private int successCount;
    private int attemptCount;
    private boolean isWeekday;
    private boolean isPeakHour;

    public HeatMapEntry() {
    }

    public HeatMapEntry(int id, int hour, int dayOfWeek, int successCount, int attemptCount, boolean isWeekday, boolean isPeakHour) {
        this.id = id;
        this.hour = hour;
        this.dayOfWeek = dayOfWeek;
        this.successCount = successCount;
        this.attemptCount = attemptCount;
        this.isWeekday = isWeekday;
        this.isPeakHour = isPeakHour;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(int dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public int getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(int successCount) {
        this.successCount = successCount;
    }

    public int getAttemptCount() {
        return attemptCount;
    }

    public void setAttemptCount(int attemptCount) {
        this.attemptCount = attemptCount;
    }

    public boolean isWeekday() {
        return isWeekday;
    }

    public void setWeekday(boolean weekday) {
        isWeekday = weekday;
    }

    public boolean isPeakHour() {
        return isPeakHour;
    }

    public void setPeakHour(boolean peakHour) {
        isPeakHour = peakHour;
    }

    public float getSuccessRate() {
        if (attemptCount == 0) {
            return 0;
        }
        return (float) successCount / attemptCount * 100;
    }
}