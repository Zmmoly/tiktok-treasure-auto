package com.tiktoktreasureauto.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.tiktoktreasureauto.models.LogEntry;
import com.tiktoktreasureauto.models.HeatMapEntry;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Database helper for storing app data
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    
    private static final String DATABASE_NAME = "tiktok_treasure_auto.db";
    private static final int DATABASE_VERSION = 1;
    
    // Table names
    private static final String TABLE_LOGS = "logs";
    private static final String TABLE_SETTINGS = "settings";
    private static final String TABLE_STATISTICS = "statistics";
    private static final String TABLE_AUTOMATION_STATUS = "automation_status";
    private static final String TABLE_SUCCESS_HEATMAP = "success_heatmap";
    
    // Common column names
    private static final String KEY_ID = "id";
    
    // Logs table columns
    private static final String KEY_LOG_MESSAGE = "message";
    private static final String KEY_LOG_TYPE = "type";
    private static final String KEY_LOG_TIMESTAMP = "timestamp";
    
    // Settings table columns
    private static final String KEY_SETTING_CHECK_INTERVAL = "check_interval";
    private static final String KEY_SETTING_NOTIFICATIONS_ENABLED = "notifications_enabled";
    private static final String KEY_SETTING_MINIMUM_VIEWER_RATIO = "min_viewer_ratio";
    
    // Statistics table columns
    private static final String KEY_STAT_BOXES_OPENED = "boxes_opened";
    private static final String KEY_STAT_LIVES_SKIPPED = "lives_skipped";
    
    // Automation status table columns
    private static final String KEY_AUTOMATION_RUNNING = "is_running";
    private static final String KEY_AUTOMATION_CURRENT_ACTION = "current_action";
    private static final String KEY_AUTOMATION_DETECTION_STATUS = "detection_status";
    
    // Heat map table columns
    private static final String KEY_HEATMAP_HOUR = "hour";
    private static final String KEY_HEATMAP_ATTEMPTS = "attempts";
    private static final String KEY_HEATMAP_SUCCESSES = "successes";
    private static final String KEY_HEATMAP_SUCCESS_RATE = "success_rate";
    private static final String KEY_HEATMAP_LAST_UPDATED = "last_updated";
    
    // Table create statements
    private static final String CREATE_TABLE_LOGS = "CREATE TABLE " + TABLE_LOGS + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_LOG_MESSAGE + " TEXT,"
            + KEY_LOG_TYPE + " TEXT,"
            + KEY_LOG_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";
    
    private static final String CREATE_TABLE_SETTINGS = "CREATE TABLE " + TABLE_SETTINGS + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_SETTING_CHECK_INTERVAL + " INTEGER DEFAULT 60,"
            + KEY_SETTING_NOTIFICATIONS_ENABLED + " INTEGER DEFAULT 1,"
            + KEY_SETTING_MINIMUM_VIEWER_RATIO + " REAL DEFAULT 2.0"
            + ")";
    
    private static final String CREATE_TABLE_STATISTICS = "CREATE TABLE " + TABLE_STATISTICS + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_STAT_BOXES_OPENED + " INTEGER DEFAULT 0,"
            + KEY_STAT_LIVES_SKIPPED + " INTEGER DEFAULT 0"
            + ")";
    
    private static final String CREATE_TABLE_AUTOMATION_STATUS = "CREATE TABLE " + TABLE_AUTOMATION_STATUS + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_AUTOMATION_RUNNING + " INTEGER DEFAULT 0,"
            + KEY_AUTOMATION_CURRENT_ACTION + " TEXT DEFAULT 'Idle',"
            + KEY_AUTOMATION_DETECTION_STATUS + " TEXT DEFAULT 'None'"
            + ")";
            
    private static final String CREATE_TABLE_SUCCESS_HEATMAP = "CREATE TABLE " + TABLE_SUCCESS_HEATMAP + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_HEATMAP_HOUR + " INTEGER NOT NULL," // 0-23 hour
            + KEY_HEATMAP_ATTEMPTS + " INTEGER DEFAULT 0,"
            + KEY_HEATMAP_SUCCESSES + " INTEGER DEFAULT 0,"
            + KEY_HEATMAP_SUCCESS_RATE + " REAL DEFAULT 0.0,"
            + KEY_HEATMAP_LAST_UPDATED + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";
    
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create tables
        db.execSQL(CREATE_TABLE_LOGS);
        db.execSQL(CREATE_TABLE_SETTINGS);
        db.execSQL(CREATE_TABLE_STATISTICS);
        db.execSQL(CREATE_TABLE_AUTOMATION_STATUS);
        db.execSQL(CREATE_TABLE_SUCCESS_HEATMAP);
        
        // Insert default setting values
        ContentValues settingsValues = new ContentValues();
        settingsValues.put(KEY_SETTING_CHECK_INTERVAL, 60);
        settingsValues.put(KEY_SETTING_NOTIFICATIONS_ENABLED, 1);
        settingsValues.put(KEY_SETTING_MINIMUM_VIEWER_RATIO, 2.0);
        db.insert(TABLE_SETTINGS, null, settingsValues);
        
        // Insert default statistics values
        ContentValues statsValues = new ContentValues();
        statsValues.put(KEY_STAT_BOXES_OPENED, 0);
        statsValues.put(KEY_STAT_LIVES_SKIPPED, 0);
        db.insert(TABLE_STATISTICS, null, statsValues);
        
        // Insert default automation status
        ContentValues statusValues = new ContentValues();
        statusValues.put(KEY_AUTOMATION_RUNNING, 0);
        statusValues.put(KEY_AUTOMATION_CURRENT_ACTION, "Idle");
        statusValues.put(KEY_AUTOMATION_DETECTION_STATUS, "None");
        db.insert(TABLE_AUTOMATION_STATUS, null, statusValues);
        
        // Initialize success heatmap with 24 hours (0-23)
        for (int hour = 0; hour < 24; hour++) {
            ContentValues heatmapValues = new ContentValues();
            heatmapValues.put(KEY_HEATMAP_HOUR, hour);
            heatmapValues.put(KEY_HEATMAP_ATTEMPTS, 0);
            heatmapValues.put(KEY_HEATMAP_SUCCESSES, 0);
            heatmapValues.put(KEY_HEATMAP_SUCCESS_RATE, 0.0);
            db.insert(TABLE_SUCCESS_HEATMAP, null, heatmapValues);
        }
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STATISTICS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_AUTOMATION_STATUS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SUCCESS_HEATMAP);
        
        // Create new tables
        onCreate(db);
    }
    
    /**
     * Add a log entry
     */
    public void addLog(LogEntry log) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_LOG_MESSAGE, log.getMessage());
        values.put(KEY_LOG_TYPE, log.getType());
        
        db.insert(TABLE_LOGS, null, values);
        db.close();
    }
    
    /**
     * Get all logs
     */
    public List<LogEntry> getAllLogs() {
        List<LogEntry> logs = new ArrayList<>();
        
        String selectQuery = "SELECT * FROM " + TABLE_LOGS + " ORDER BY " + KEY_LOG_TIMESTAMP + " DESC";
        
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        if (cursor.moveToFirst()) {
            do {
                LogEntry log = new LogEntry();
                log.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID)));
                log.setMessage(cursor.getString(cursor.getColumnIndex(KEY_LOG_MESSAGE)));
                log.setType(cursor.getString(cursor.getColumnIndex(KEY_LOG_TYPE)));
                log.setTimestamp(cursor.getString(cursor.getColumnIndex(KEY_LOG_TIMESTAMP)));
                
                logs.add(log);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        
        return logs;
    }
    
    /**
     * Clear all logs
     */
    public void clearLogs() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_LOGS, null, null);
        db.close();
    }
    
    /**
     * Get check interval from settings
     */
    public int getCheckInterval() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_SETTING_CHECK_INTERVAL + " FROM " + TABLE_SETTINGS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        int interval = 60; // Default: 60 seconds
        
        if (cursor.moveToFirst()) {
            interval = cursor.getInt(cursor.getColumnIndex(KEY_SETTING_CHECK_INTERVAL));
        }
        
        cursor.close();
        db.close();
        
        return interval;
    }
    
    /**
     * Update check interval in settings
     */
    public void updateCheckInterval(int seconds) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_SETTING_CHECK_INTERVAL, seconds);
        
        db.update(TABLE_SETTINGS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
    }
    
    /**
     * Get notifications enabled setting
     */
    public boolean getNotificationsEnabled() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_SETTING_NOTIFICATIONS_ENABLED + " FROM " + TABLE_SETTINGS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        boolean enabled = true; // Default: enabled
        
        if (cursor.moveToFirst()) {
            enabled = cursor.getInt(cursor.getColumnIndex(KEY_SETTING_NOTIFICATIONS_ENABLED)) == 1;
        }
        
        cursor.close();
        db.close();
        
        return enabled;
    }
    
    /**
     * Update notifications enabled setting
     */
    public void updateNotificationsEnabled(boolean enabled) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_SETTING_NOTIFICATIONS_ENABLED, enabled ? 1 : 0);
        
        db.update(TABLE_SETTINGS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
    }
    
    /**
     * Get minimum viewer ratio setting
     */
    public float getMinimumViewerRatio() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_SETTING_MINIMUM_VIEWER_RATIO + " FROM " + TABLE_SETTINGS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        float ratio = 2.0f; // Default: 2.0 viewers per box
        
        if (cursor.moveToFirst()) {
            ratio = cursor.getFloat(cursor.getColumnIndex(KEY_SETTING_MINIMUM_VIEWER_RATIO));
        }
        
        cursor.close();
        db.close();
        
        return ratio;
    }
    
    /**
     * Update minimum viewer ratio setting
     */
    public void updateMinimumViewerRatio(float ratio) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_SETTING_MINIMUM_VIEWER_RATIO, ratio);
        
        db.update(TABLE_SETTINGS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
    }
    
    /**
     * Get boxes opened count
     */
    public int getBoxesOpened() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_STAT_BOXES_OPENED + " FROM " + TABLE_STATISTICS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        int count = 0;
        
        if (cursor.moveToFirst()) {
            count = cursor.getInt(cursor.getColumnIndex(KEY_STAT_BOXES_OPENED));
        }
        
        cursor.close();
        db.close();
        
        return count;
    }
    
    /**
     * Increment boxes opened count and return new value
     */
    public int incrementBoxesOpened() {
        int currentCount = getBoxesOpened();
        int newCount = currentCount + 1;
        
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_STAT_BOXES_OPENED, newCount);
        
        db.update(TABLE_STATISTICS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
        
        return newCount;
    }
    
    /**
     * Get lives skipped count
     */
    public int getLivesSkipped() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_STAT_LIVES_SKIPPED + " FROM " + TABLE_STATISTICS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        int count = 0;
        
        if (cursor.moveToFirst()) {
            count = cursor.getInt(cursor.getColumnIndex(KEY_STAT_LIVES_SKIPPED));
        }
        
        cursor.close();
        db.close();
        
        return count;
    }
    
    /**
     * Increment lives skipped count and return new value
     */
    public int incrementLivesSkipped() {
        int currentCount = getLivesSkipped();
        int newCount = currentCount + 1;
        
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_STAT_LIVES_SKIPPED, newCount);
        
        db.update(TABLE_STATISTICS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
        
        return newCount;
    }
    
    /**
     * Reset statistics
     */
    public void resetStatistics() {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_STAT_BOXES_OPENED, 0);
        values.put(KEY_STAT_LIVES_SKIPPED, 0);
        
        db.update(TABLE_STATISTICS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
    }
    
    /**
     * Get automation status
     */
    public boolean getAutomationStatus() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_AUTOMATION_RUNNING + " FROM " + TABLE_AUTOMATION_STATUS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        boolean running = false;
        
        if (cursor.moveToFirst()) {
            running = cursor.getInt(cursor.getColumnIndex(KEY_AUTOMATION_RUNNING)) == 1;
        }
        
        cursor.close();
        db.close();
        
        return running;
    }
    
    /**
     * Update automation status
     */
    public void updateAutomationStatus(boolean running) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_AUTOMATION_RUNNING, running ? 1 : 0);
        
        db.update(TABLE_AUTOMATION_STATUS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
    }
    
    /**
     * Get current action
     */
    public String getCurrentAction() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_AUTOMATION_CURRENT_ACTION + " FROM " + TABLE_AUTOMATION_STATUS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        String action = "Idle";
        
        if (cursor.moveToFirst()) {
            action = cursor.getString(cursor.getColumnIndex(KEY_AUTOMATION_CURRENT_ACTION));
        }
        
        cursor.close();
        db.close();
        
        return action;
    }
    
    /**
     * Update current action
     */
    public void updateCurrentAction(String action) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_AUTOMATION_CURRENT_ACTION, action);
        
        db.update(TABLE_AUTOMATION_STATUS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
    }
    
    /**
     * Get detection status
     */
    public String getDetectionStatus() {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT " + KEY_AUTOMATION_DETECTION_STATUS + " FROM " + TABLE_AUTOMATION_STATUS + " WHERE " + KEY_ID + " = 1";
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        String status = "None";
        
        if (cursor.moveToFirst()) {
            status = cursor.getString(cursor.getColumnIndex(KEY_AUTOMATION_DETECTION_STATUS));
        }
        
        cursor.close();
        db.close();
        
        return status;
    }
    
    /**
     * Update detection status
     */
    public void updateDetectionStatus(String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_AUTOMATION_DETECTION_STATUS, status);
        
        db.update(TABLE_AUTOMATION_STATUS, values, KEY_ID + " = ?", new String[]{"1"});
        db.close();
    }
    
    /**
     * Get all heat map entries
     */
    public List<HeatMapEntry> getAllHeatMapEntries() {
        List<HeatMapEntry> entries = new ArrayList<>();
        
        String selectQuery = "SELECT * FROM " + TABLE_SUCCESS_HEATMAP + " ORDER BY " + KEY_HEATMAP_HOUR + " ASC";
        
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        if (cursor.moveToFirst()) {
            do {
                HeatMapEntry entry = new HeatMapEntry();
                entry.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID)));
                entry.setHour(cursor.getInt(cursor.getColumnIndex(KEY_HEATMAP_HOUR)));
                entry.setAttempts(cursor.getInt(cursor.getColumnIndex(KEY_HEATMAP_ATTEMPTS)));
                entry.setSuccesses(cursor.getInt(cursor.getColumnIndex(KEY_HEATMAP_SUCCESSES)));
                entry.setSuccessRate(cursor.getFloat(cursor.getColumnIndex(KEY_HEATMAP_SUCCESS_RATE)));
                entry.setLastUpdated(cursor.getString(cursor.getColumnIndex(KEY_HEATMAP_LAST_UPDATED)));
                
                entries.add(entry);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        
        return entries;
    }
    
    /**
     * Get heat map entry for a specific hour
     */
    public HeatMapEntry getHeatMapEntryForHour(int hour) {
        SQLiteDatabase db = this.getReadableDatabase();
        
        String selectQuery = "SELECT * FROM " + TABLE_SUCCESS_HEATMAP + " WHERE " + KEY_HEATMAP_HOUR + " = " + hour;
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        HeatMapEntry entry = null;
        
        if (cursor.moveToFirst()) {
            entry = new HeatMapEntry();
            entry.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID)));
            entry.setHour(cursor.getInt(cursor.getColumnIndex(KEY_HEATMAP_HOUR)));
            entry.setAttempts(cursor.getInt(cursor.getColumnIndex(KEY_HEATMAP_ATTEMPTS)));
            entry.setSuccesses(cursor.getInt(cursor.getColumnIndex(KEY_HEATMAP_SUCCESSES)));
            entry.setSuccessRate(cursor.getFloat(cursor.getColumnIndex(KEY_HEATMAP_SUCCESS_RATE)));
            entry.setLastUpdated(cursor.getString(cursor.getColumnIndex(KEY_HEATMAP_LAST_UPDATED)));
        }
        
        cursor.close();
        db.close();
        
        return entry;
    }
    
    /**
     * Record a treasure box attempt
     */
    public void recordBoxAttempt(boolean success) {
        // Get current hour
        Calendar calendar = Calendar.getInstance();
        int currentHour = calendar.get(Calendar.HOUR_OF_DAY); // 0-23
        
        // Get entry for current hour
        HeatMapEntry entry = getHeatMapEntryForHour(currentHour);
        
        if (entry == null) {
            // This shouldn't happen since we initialize with all 24 hours, but just in case
            entry = new HeatMapEntry(currentHour);
        }
        
        // Update counts
        entry.setAttempts(entry.getAttempts() + 1);
        if (success) {
            entry.setSuccesses(entry.getSuccesses() + 1);
        }
        
        // Calculate new success rate
        float successRate = entry.calculateSuccessRate();
        entry.setSuccessRate(successRate);
        
        // Update in database
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(KEY_HEATMAP_ATTEMPTS, entry.getAttempts());
        values.put(KEY_HEATMAP_SUCCESSES, entry.getSuccesses());
        values.put(KEY_HEATMAP_SUCCESS_RATE, entry.getSuccessRate());
        // Last updated timestamp will be updated automatically with DEFAULT CURRENT_TIMESTAMP
        
        db.update(TABLE_SUCCESS_HEATMAP, values, KEY_HEATMAP_HOUR + " = ?", new String[]{String.valueOf(currentHour)});
        db.close();
    }
    
    /**
     * Reset heat map data
     */
    public void resetHeatMap() {
        SQLiteDatabase db = this.getWritableDatabase();
        
        for (int hour = 0; hour < 24; hour++) {
            ContentValues values = new ContentValues();
            values.put(KEY_HEATMAP_ATTEMPTS, 0);
            values.put(KEY_HEATMAP_SUCCESSES, 0);
            values.put(KEY_HEATMAP_SUCCESS_RATE, 0.0);
            
            db.update(TABLE_SUCCESS_HEATMAP, values, KEY_HEATMAP_HOUR + " = ?", new String[]{String.valueOf(hour)});
        }
        
        db.close();
    }
}